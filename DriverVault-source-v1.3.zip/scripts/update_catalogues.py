#!/usr/bin/env python3
import json, re, sys, urllib.request, html, unicodedata, difflib
from pathlib import Path
from urllib.parse import quote

CAT=Path("assets/catalog/catalog.json")
data=json.loads(CAT.read_text(encoding="utf-8"))

MAKES=sorted([
"Abarth","Acura","Alfa Romeo","Alpine","Alumi Craft","AMC","AMG Transport Dynamics",
"Apollo","Ariel","Ascari","Aston Martin","ATS","Audi","Austin-Healey","Auto Union",
"Automobili Pininfarina","Autozam","BAC","Bentley","BMW","Brabham","Bugatti","Buick",
"Cadillac","Can-Am","Casey Currie Motorsports","Caterham","Chevrolet","Citroën","CUPRA",
"Czinger","Datsun","DeBerti","DeLorean","Dodge","Donkervoort","DS Automobiles","Eagle",
"Exomotive","Ferrari","FIAT","Ford","Formula Drift","Forsberg Racing","Funco","GMC",
"Hennessey","Holden","Honda","Hoonigan","Hot Wheels","HSV","HUMMER","Hyundai","Infiniti",
"International","Italdesign","Jaguar","Jeep","Koenigsegg","KTM","Lamborghini","Lancia",
"Land Rover","Lexus","Lincoln","Local Motors","Lola","Lotus","Lucid","Lynk & Co","Maserati",
"Mazda","McLaren","Mercedes-AMG","Mercedes-Benz","Mercury","MG","MINI","Mitsubishi",
"Morgan","Morris","Mosler","Napier","NIO","Nissan","Noble","Oldsmobile","Opel","Pagani",
"Peel","Penhall","Peugeot","Plymouth","Polaris","Pontiac","Porsche","RAESR","Radical",
"Renault","Rimac","Rivian","Rossion","RUF","Saleen","Schuppan","Shelby","Sierra Cars",
"Spania GTA","Subaru","Toyota","TVR","Ultima","Vauxhall","Volkswagen","Volvo","W Motors",
"Wuling","Xpeng","Zenvo"
], key=len, reverse=True)

def fetch(url):
    req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 DriverVault/1.0"})
    with urllib.request.urlopen(req,timeout=45) as r:
        return r.read().decode("utf-8","replace")

def strip_tags(x):
    return re.sub(r"\s+"," ",html.unescape(re.sub(r"<[^>]+>","",x))).strip()

def split_make(name):
    for make in MAKES:
        if name == make or name.startswith(make+" "):
            return make, name[len(make):].strip()
    parts=name.split(" ",1)
    return (parts[0],parts[1] if len(parts)>1 else "")

def game(gid):
    return next(g for g in data["games"] if g["id"]==gid)


ALLBRANDS_CATALOG="https://dobbygl.github.io/allbrands-api/v1/catalog.json"

def fetch_bytes(url, timeout=30):
    req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 DriverVault/1.3","Accept":"image/webp,image/*,*/*;q=0.8"})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        body=r.read()
        return r.status, r.headers.get("Content-Type", ""), body

def norm(s):
    s=unicodedata.normalize("NFKD",str(s)).encode("ascii","ignore").decode().lower()
    s=re.sub(r'\\b(edition|concept|coupe|coupé|convertible|roadster|sedan|hatchback)\\b',' ',s)
    return re.sub(r'[^a-z0-9]+',' ',s).strip()

def image_catalog():
    root=json.loads(fetch(ALLBRANDS_CATALOG))
    return root, root.get("models",[])

def match_image(make, model, models, base):
    bm=norm(make); mm=norm(model)
    brand=[x for x in models if norm(x.get("brand",""))==bm]
    if not brand: return ""
    # exact normalized model first
    for x in brand:
        if norm(x.get("name",x.get("model","")))==mm or norm(x.get("model",""))==mm:
            return f"{base}/{x['brand']}/{x['model']}/medium.webp"
    # conservative fuzzy match; reject weak guesses
    scored=[]
    for x in brand:
        candidate=norm(x.get("name",x.get("model","")))
        ratio=difflib.SequenceMatcher(None,mm,candidate).ratio()
        if mm in candidate or candidate in mm: ratio=max(ratio,.90)
        scored.append((ratio,x))
    if scored:
        ratio,x=max(scored,key=lambda z:z[0])
        if ratio>=.78:
            return f"{base}/{x['brand']}/{x['model']}/medium.webp"
    return ""

def add_verified_images():
    root,models=image_catalog(); base=root["base"]
    matched=0
    for g in data["games"]:
        for v in g.get("vehicles",[]):
            u=match_image(v.get("make",""),v.get("model",""),models,base)
            if u:
                v["image"]=u; matched+=1
    # Verify representative URLs BEFORE allowing the APK build.
    fh=game("fh5")["vehicles"]
    candidates=[v for v in fh if v.get("image")][:12]
    if len(candidates)<6:
        raise RuntimeError(f"Image validation FAILED: only {len(candidates)} FH5 image matches")
    ok=0
    for v in candidates[:8]:
        try:
            status,ctype,body=fetch_bytes(v["image"],20)
            if status==200 and ctype.startswith("image/") and len(body)>5000: ok+=1
        except Exception as e:
            print("Image check failed:",v.get("make"),v.get("model"),e)
    if ok<6:
        raise RuntimeError(f"Image validation FAILED: only {ok}/8 sample image URLs returned real image bytes")
    coverage=sum(1 for v in fh if v.get("image"))
    print(f"FH5 images: {coverage}/902 mapped; {ok}/8 live sample URLs verified")
    print(f"All games image mappings: {matched}")

def update_fh5():
    raw=fetch("https://forza.net/fh5cars")
    rows=re.findall(r"<tr[^>]*>(.*?)</tr>",raw,re.I|re.S)
    out=[]
    for row in rows:
        cells=[strip_tags(x) for x in re.findall(r"<td[^>]*>(.*?)</td>",row,re.I|re.S)]
        if len(cells)<6 or not re.match(r"^\d{4}\s",cells[0]): continue
        year,name=cells[0].split(" ",1)
        make,model=split_make(name)
        car_id=re.sub(r"\D","",cells[5])
        if not car_id: continue
        out.append({
          "id":f"fh5:{car_id}","year":year,"make":make,"model":model,
          "class":cells[1],"drive":"","collect":cells[2],"added":cells[3],
          "nickname":cells[4],"image":""
        })
    if len(out)!=902:
        raise RuntimeError(f"FH5 validation FAILED: expected 902, parsed {len(out)}")
    g=game("fh5"); g["vehicles"]=out; g["official_total"]=902
    g["source"]="https://forza.net/fh5cars"; g["verifiedAt"]="2026-09-27"
    print("FH5: 902/902 validated")

def update_gt7():
    raw=fetch("https://raw.githubusercontent.com/jbhoorasingh/gt7-datalogger/main/backend/app/data/cars.json")
    root=json.loads(raw); cars=root["cars"]; out=[]
    for cid,c in cars.items():
        name=(c.get("name") or "").strip()
        full=(c.get("full_name") or "").strip()
        make=(c.get("manufacturer") or "").strip()
        model=name or full
        # Official Gran Turismo car-list detail route uses the numeric vehicle id.
        image=f"https://www.gran-turismo.com/images/c/i1QHdbil7nGQk.jpg" if False else ""
        out.append({
          "id":f"gt7:{cid}","year":str(c.get("year") or ""),
          "make":make,"model":model,"class":str(c.get("category") or ""),
          "drive":str(c.get("drivetrain") or ""),"image":image
        })
    if len(out)<570:
        raise RuntimeError(f"GT7 validation FAILED: parsed only {len(out)}")
    g=game("gt7"); g["vehicles"]=out; g["official_total"]=len(out)
    g["source"]=root.get("meta",{}).get("source","Gran Turismo official car list")
    g["verifiedAt"]=root.get("meta",{}).get("generated","2026-09-27")
    print(f"GT7: {len(out)} vehicles validated")

update_fh5()
update_gt7()
add_verified_images()

# Hard validation for catalogues we have completed locally.
expected={"assetto":178,"snowrunner":116,"alaskan":19,"mudrunner":35}
for gid,n in expected.items():
    actual=len(game(gid)["vehicles"])
    if actual!=n: raise RuntimeError(f"{gid}: expected {n}, got {actual}")
    print(f"{gid}: {actual}/{n} validated")

data["version"]="1.3.0"
CAT.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
print("Catalogue validation complete.")
