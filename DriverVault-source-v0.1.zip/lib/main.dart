import 'package:flutter/material.dart';
import 'catalog.dart';
import 'models.dart';
import 'store.dart';

void main() => runApp(const DriverVaultApp());

class DriverVaultApp extends StatelessWidget {
  const DriverVaultApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'DriverVault',
    theme: ThemeData(
      brightness: Brightness.dark,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF6BE585), brightness: Brightness.dark),
      useMaterial3: true,
      scaffoldBackgroundColor: const Color(0xFF101312),
      cardTheme: const CardThemeData(margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6)),
    ),
    home: const VaultHome(),
  );
}

class VaultHome extends StatefulWidget {
  const VaultHome({super.key});
  @override State<VaultHome> createState() => _VaultHomeState();
}

class _VaultHomeState extends State<VaultHome> {
  final store = VaultStore();
  Catalog? catalog;
  List<SavedSetup> setups = [];
  List<HardwareProfile> hardware = [];
  String? gameId;
  int tab = 0;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    final c = await Catalog.load();
    final s = await store.loadSetups();
    final h = await store.loadHardware();
    setState(() { catalog=c; setups=s; hardware=h; gameId=c.games.first.id; });
  }

  @override
  Widget build(BuildContext context) {
    if (catalog == null) return const Scaffold(body: Center(child:CircularProgressIndicator()));
    final game = catalog!.games.firstWhere((g)=>g.id==gameId);
    return Scaffold(
      appBar: AppBar(
        title: const Column(crossAxisAlignment:CrossAxisAlignment.start, children:[
          Text('DriverVault', style:TextStyle(fontWeight:FontWeight.w800)),
          Text('Every game. Every setup. Saved.', style:TextStyle(fontSize:11,fontWeight:FontWeight.w400)),
        ]),
      ),
      body: Column(children:[
        SizedBox(height:78, child:ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal:16,vertical:8),
          scrollDirection:Axis.horizontal,
          itemCount:catalog!.games.length + 1,
          separatorBuilder:(_,__)=>const SizedBox(width:8),
          itemBuilder:(context,i){
            if(i==catalog!.games.length) return ActionChip(
              avatar:const Icon(Icons.add), label:const Text('Custom game'),
              onPressed:_addCustomGameInfo);
            final g=catalog!.games[i]; final selected=g.id==gameId;
            return ChoiceChip(
              selected:selected,
              avatar:CircleAvatar(child:Text(g.shortName.substring(0,1))),
              label:Text(g.shortName),
              onSelected:(_)=>setState(()=>gameId=g.id));
          },
        )),
        Padding(
          padding:const EdgeInsets.fromLTRB(16,8,16,6),
          child:Row(children:[
            Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
              Text(game.name,style:Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight:FontWeight.bold)),
              Text('${setups.where((s)=>s.gameId==game.id).length} saved setups',style:Theme.of(context).textTheme.bodySmall),
            ])),
            FilledButton.icon(onPressed:()=>_chooseVehicle(game),icon:const Icon(Icons.add),label:const Text('Setup')),
          ]),
        ),
        Expanded(child:_body(game)),
      ]),
      bottomNavigationBar:NavigationBar(
        selectedIndex:tab,
        onDestinationSelected:(i)=>setState(()=>tab=i),
        destinations:const [
          NavigationDestination(icon:Icon(Icons.dashboard_outlined),selectedIcon:Icon(Icons.dashboard),label:'Vault'),
          NavigationDestination(icon:Icon(Icons.sports_motorsports_outlined),selectedIcon:Icon(Icons.sports_motorsports),label:'Vehicles'),
          NavigationDestination(icon:Icon(Icons.settings_input_component_outlined),selectedIcon:Icon(Icons.settings_input_component),label:'Hardware'),
        ],
      ),
    );
  }

  Widget _body(GameEntry game) {
    if(tab==2) return _hardware();
    if(tab==1) return _vehicles(game);
    final list=setups.where((s)=>s.gameId==game.id).toList()
      ..sort((a,b)=>(b.favourite?1:0).compareTo(a.favourite?1:0));
    if(list.isEmpty) return _empty('No setups yet','Choose a vehicle and save your first setup.',Icons.tune);
    return ListView.builder(
      padding:const EdgeInsets.only(bottom:24),
      itemCount:list.length,
      itemBuilder:(context,i){
        final s=list[i];
        final v=catalog!.vehicles.where((v)=>v.id==s.vehicleId).firstOrNull;
        return Card(child:ListTile(
          leading:Icon(s.favourite?Icons.star:Icons.tune),
          title:Text(s.name,style:const TextStyle(fontWeight:FontWeight.w700)),
          subtitle:Text(v?.displayName ?? s.vehicleId),
          trailing:const Icon(Icons.chevron_right),
          onTap:()=>_editSetup(game,v,s),
        ));
      },
    );
  }

  Widget _vehicles(GameEntry game) {
    final vehicles=catalog!.vehicles.where((v)=>v.gameId==game.id).toList();
    return ListView.builder(
      padding:const EdgeInsets.only(bottom:24),
      itemCount:vehicles.length,
      itemBuilder:(context,i){
        final v=vehicles[i];
        final count=setups.where((s)=>s.vehicleId==v.id).length;
        return ListTile(
          leading:const CircleAvatar(child:Icon(Icons.directions_car)),
          title:Text(v.displayName),
          subtitle:Text('$count saved ${count==1?'setup':'setups'}'),
          trailing:const Icon(Icons.add_circle_outline),
          onTap:()=>_editSetup(game,v,null),
        );
      },
    );
  }

  Widget _hardware() {
    return ListView(
      padding:const EdgeInsets.only(bottom:24),
      children:[
        ListTile(
          title:const Text('Hardware profiles',style:TextStyle(fontWeight:FontWeight.bold)),
          subtitle:const Text('Wheel bases, wheels, pedals and controllers'),
          trailing:IconButton(icon:const Icon(Icons.add),onPressed:_addHardware),
        ),
        if(hardware.isEmpty) _empty('No hardware profiles','Add your wheel, controller or other driving hardware.',Icons.settings_input_component)
        else ...hardware.map((h)=>Card(child:ListTile(
          leading:const Icon(Icons.settings_input_component),
          title:Text(h.name), subtitle:Text('${h.type}${h.notes.isEmpty?'':' • ${h.notes}'}'),
        ))),
      ],
    );
  }

  Widget _empty(String title,String body,IconData icon)=>Center(child:Padding(
    padding:const EdgeInsets.all(32),
    child:Column(mainAxisSize:MainAxisSize.min,children:[
      Icon(icon,size:54),const SizedBox(height:12),
      Text(title,style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),
      const SizedBox(height:6),Text(body,textAlign:TextAlign.center),
    ]),
  ));

  Future<void> _chooseVehicle(GameEntry game) async {
    final vehicles=catalog!.vehicles.where((v)=>v.gameId==game.id).toList();
    final v=await showModalBottomSheet<VehicleEntry>(
      context:context,isScrollControlled:true,
      builder:(context)=>VehiclePicker(vehicles:vehicles),
    );
    if(v!=null && mounted) _editSetup(game,v,null);
  }

  Future<void> _editSetup(GameEntry game,VehicleEntry? vehicle,SavedSetup? existing) async {
    if(vehicle==null) return;
    final result=await Navigator.push<SavedSetup>(context,MaterialPageRoute(
      builder:(_)=>SetupEditor(game:game,vehicle:vehicle,existing:existing)));
    if(result==null) return;
    setState(() {
      final i=setups.indexWhere((s)=>s.id==result.id);
      if(i>=0) setups[i]=result; else setups.add(result);
    });
    await store.saveSetups(setups);
  }

  Future<void> _addHardware() async {
    final name=TextEditingController(), notes=TextEditingController();
    String type='Wheel base';
    final ok=await showDialog<bool>(context:context,builder:(context)=>StatefulBuilder(
      builder:(context,setLocal)=>AlertDialog(
        title:const Text('Add hardware'),
        content:Column(mainAxisSize:MainAxisSize.min,children:[
          TextField(controller:name,decoration:const InputDecoration(labelText:'Name',hintText:'RS50 8 Nm')),
          DropdownButtonFormField(value:type,items:['Wheel base','Wheel','Pedals','Controller','Other'].map((x)=>DropdownMenuItem(value:x,child:Text(x))).toList(),onChanged:(v)=>setLocal(()=>type=v!)),
          TextField(controller:notes,decoration:const InputDecoration(labelText:'Notes')),
        ]),
        actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),
          FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Save'))],
      )));
    if(ok==true && name.text.trim().isNotEmpty){
      setState(()=>hardware.add(HardwareProfile(id:DateTime.now().microsecondsSinceEpoch.toString(),name:name.text.trim(),type:type,notes:notes.text.trim())));
      await store.saveHardware(hardware);
    }
  }

  void _addCustomGameInfo()=>showDialog(context:context,builder:(context)=>AlertDialog(
    title:const Text('Custom games'),
    content:const Text('Custom game creation is part of the data model and will be enabled in the next catalogue-management pass. The built-in catalogue remains separate from your personal setups.'),
    actions:[FilledButton(onPressed:()=>Navigator.pop(context),child:const Text('OK'))],
  ));
}

class VehiclePicker extends StatefulWidget {
  const VehiclePicker({super.key,required this.vehicles});
  final List<VehicleEntry> vehicles;
  @override State<VehiclePicker> createState()=>_VehiclePickerState();
}
class _VehiclePickerState extends State<VehiclePicker>{
  String q='';
  @override Widget build(BuildContext context){
    final list=widget.vehicles.where((v)=>v.displayName.toLowerCase().contains(q.toLowerCase())).toList();
    return SafeArea(child:Padding(padding:EdgeInsets.only(bottom:MediaQuery.of(context).viewInsets.bottom),child:SizedBox(
      height:520,child:Column(children:[
        Padding(padding:const EdgeInsets.all(16),child:TextField(
          autofocus:true,onChanged:(v)=>setState(()=>q=v),
          decoration:const InputDecoration(prefixIcon:Icon(Icons.search),labelText:'Search vehicles'))),
        Expanded(child:ListView.builder(itemCount:list.length,itemBuilder:(context,i)=>ListTile(
          leading:const Icon(Icons.directions_car),title:Text(list[i].displayName),
          onTap:()=>Navigator.pop(context,list[i])))),
      ]),
    )));
  }
}

class SetupEditor extends StatefulWidget {
  const SetupEditor({super.key,required this.game,required this.vehicle,this.existing});
  final GameEntry game; final VehicleEntry vehicle; final SavedSetup? existing;
  @override State<SetupEditor> createState()=>_SetupEditorState();
}
class _SetupEditorState extends State<SetupEditor>{
  late TextEditingController name,notes;
  late bool favourite;
  final ctrls=<String,TextEditingController>{};

  List<String> get fields => widget.game.id=='fh5'
    ? ['Front tyre pressure','Rear tyre pressure','Final drive','Front camber','Rear camber','Front toe','Rear toe','Caster','Front ARB','Rear ARB','Front springs','Rear springs','Front ride height','Rear ride height','Front rebound','Rear rebound','Front bump','Rear bump','Front aero','Rear aero','Brake balance','Brake pressure','Front differential accel','Front differential decel','Rear differential accel','Rear differential decel','Centre balance']
    : ['Steering angle','Ackerman','Caster','Kingpin angle','Front tyre pressure','Rear tyre pressure','Front spring stiffness','Rear spring stiffness','Front damper','Rear damper','Front ARB','Rear ARB','Final drive'];

  @override void initState(){
    super.initState();
    name=TextEditingController(text:widget.existing?.name ?? 'My setup');
    notes=TextEditingController(text:widget.existing?.notes ?? '');
    favourite=widget.existing?.favourite ?? false;
    for(final f in fields) ctrls[f]=TextEditingController(text:widget.existing?.values[f] ?? '');
  }
  @override void dispose(){name.dispose();notes.dispose();for(final c in ctrls.values)c.dispose();super.dispose();}

  @override Widget build(BuildContext context)=>Scaffold(
    appBar:AppBar(title:Text(widget.vehicle.displayName),actions:[
      IconButton(onPressed:()=>setState(()=>favourite=!favourite),icon:Icon(favourite?Icons.star:Icons.star_border)),
    ]),
    body:ListView(padding:const EdgeInsets.all(16),children:[
      Text(widget.game.name,style:Theme.of(context).textTheme.labelLarge),
      const SizedBox(height:8),
      TextField(controller:name,decoration:const InputDecoration(labelText:'Setup name')),
      const SizedBox(height:18),
      Text('Settings',style:Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight:FontWeight.bold)),
      const SizedBox(height:8),
      ...fields.map((f)=>Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(
        controller:ctrls[f],keyboardType:const TextInputType.numberWithOptions(decimal:true,signed:true),
        decoration:InputDecoration(labelText:f),
      ))),
      TextField(controller:notes,maxLines:4,decoration:const InputDecoration(labelText:'Notes',hintText:'Track, surface, changes to try...')),
      const SizedBox(height:20),
      FilledButton.icon(onPressed:_save,icon:const Icon(Icons.save),label:const Text('Save setup')),
      if(widget.existing!=null) TextButton.icon(onPressed:_delete,icon:const Icon(Icons.delete_outline),label:const Text('Delete')),
      const SizedBox(height:30),
    ]),
  );

  void _save(){
    final s=SavedSetup(
      id:widget.existing?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      gameId:widget.game.id,vehicleId:widget.vehicle.id,
      name:name.text.trim().isEmpty?'My setup':name.text.trim(),
      notes:notes.text.trim(),favourite:favourite,
      values:{for(final e in ctrls.entries) if(e.value.text.trim().isNotEmpty)e.key:e.value.text.trim()},
    );
    Navigator.pop(context,s);
  }
  void _delete(){
    // Deletion will be wired to the central store in the next pass.
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Delete workflow is coming in the next pass.')));
  }
}

extension FirstOrNull<T> on Iterable<T>{T? get firstOrNull=>isEmpty?null:first;}
