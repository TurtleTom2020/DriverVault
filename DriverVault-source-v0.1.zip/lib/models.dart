class GameEntry {
  const GameEntry({required this.id, required this.name, required this.shortName, required this.category});
  final String id, name, shortName, category;
}

class VehicleEntry {
  const VehicleEntry({required this.id, required this.gameId, required this.make, required this.model, this.year});
  final String id, gameId, make, model;
  final int? year;
  String get displayName => '${year == null ? '' : '$year '}$make $model'.trim();
}

class SavedSetup {
  SavedSetup({
    required this.id,
    required this.gameId,
    required this.vehicleId,
    required this.name,
    required this.values,
    this.notes = '',
    this.favourite = false,
  });
  final String id, gameId, vehicleId;
  String name, notes;
  bool favourite;
  Map<String, String> values;

  Map<String, dynamic> toJson() => {
    'id': id, 'gameId': gameId, 'vehicleId': vehicleId, 'name': name,
    'notes': notes, 'favourite': favourite, 'values': values,
  };

  factory SavedSetup.fromJson(Map<String, dynamic> j) => SavedSetup(
    id: j['id'], gameId: j['gameId'], vehicleId: j['vehicleId'], name: j['name'],
    notes: j['notes'] ?? '', favourite: j['favourite'] ?? false,
    values: Map<String, String>.from(j['values'] ?? {}),
  );
}

class HardwareProfile {
  HardwareProfile({required this.id, required this.name, required this.type, this.notes = ''});
  final String id;
  String name, type, notes;
  Map<String, dynamic> toJson() => {'id':id,'name':name,'type':type,'notes':notes};
  factory HardwareProfile.fromJson(Map<String,dynamic> j) =>
      HardwareProfile(id:j['id'],name:j['name'],type:j['type'],notes:j['notes'] ?? '');
}
