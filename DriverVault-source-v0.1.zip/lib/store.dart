import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'models.dart';

class VaultStore {
  static const _setupKey = 'drivervault_setups_v1';
  static const _hardwareKey = 'drivervault_hardware_v1';

  Future<List<SavedSetup>> loadSetups() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_setupKey);
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((e) => SavedSetup.fromJson(Map<String,dynamic>.from(e))).toList();
  }

  Future<void> saveSetups(List<SavedSetup> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_setupKey, jsonEncode(items.map((e) => e.toJson()).toList()));
  }

  Future<List<HardwareProfile>> loadHardware() async {
    final p = await SharedPreferences.getInstance();
    final raw = p.getString(_hardwareKey);
    if (raw == null) return [];
    return (jsonDecode(raw) as List).map((e) => HardwareProfile.fromJson(Map<String,dynamic>.from(e))).toList();
  }

  Future<void> saveHardware(List<HardwareProfile> items) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_hardwareKey, jsonEncode(items.map((e) => e.toJson()).toList()));
  }
}
