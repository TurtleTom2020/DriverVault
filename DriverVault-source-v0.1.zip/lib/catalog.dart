import 'dart:convert';
import 'package:flutter/services.dart';
import 'models.dart';

class Catalog {
  final List<GameEntry> games;
  final List<VehicleEntry> vehicles;
  Catalog(this.games, this.vehicles);

  static Future<Catalog> load() async {
    final raw = await rootBundle.loadString('assets/catalog/catalog.json');
    final data = jsonDecode(raw);
    final games = <GameEntry>[];
    final vehicles = <VehicleEntry>[];
    for (final g in data['games']) {
      games.add(GameEntry(id:g['id'],name:g['name'],shortName:g['shortName'],category:g['category']));
      for (final v in g['vehicles']) {
        vehicles.add(VehicleEntry(
          id:v['id'], gameId:g['id'], make:v['make'], model:v['model'], year:v['year']));
      }
    }
    return Catalog(games, vehicles);
  }
}
