
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg = Color(0xFF08070C);
const panel = Color(0xFF14111B);
const panel2 = Color(0xFF1B1625);
const purple = Color(0xFF9D42FF);
const gold = Color(0xFFFFC438);

void main() => runApp(const DriverVaultApp());

class DriverVaultApp extends StatelessWidget {
  const DriverVaultApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DriverVault',
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          brightness: Brightness.dark,
        ),
        navigationBarTheme: const NavigationBarThemeData(
          backgroundColor: Color(0xFF0D0A11),
          indicatorColor: Color(0xFF49206D),
        ),
      ),
      home: const VaultShell(),
    );
  }
}

class VaultShell extends StatefulWidget {
  const VaultShell({super.key});
  @override
  State<VaultShell> createState() => _VaultShellState();
}

class _VaultShellState extends State<VaultShell> {
  int tab = 0;
  List<dynamic> games = [];
  List<dynamic> saved = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final data = jsonDecode(
      await rootBundle.loadString('assets/catalog/catalog.json'),
    );
    final prefs = await SharedPreferences.getInstance();
    games = data['games'];
    saved = jsonDecode(prefs.getString('dv_saved') ?? '[]');
    if (mounted) setState(() {});
  }

  Future<void> persist() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('dv_saved', jsonEncode(saved));
  }

  void addSetup(Map<String, dynamic> setup) {
    saved.add(setup);
    persist();
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: IndexedStack(
          index: tab,
          children: [
            HomeScreen(
              games: games,
              saved: saved,
              openCatalogue: () => setState(() => tab = 1),
              openSetups: () => setState(() => tab = 2),
            ),
            CatalogueScreen(games: games, onSave: addSetup),
            SetupsScreen(
              saved: saved,
              onDelete: (s) {
                saved.remove(s);
                persist();
                setState(() {});
              },
            ),
            const HardwareScreen(),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        height: 72,
        selectedIndex: tab,
        onDestinationSelected: (value) => setState(() => tab = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_rounded), label: 'Home'),
          NavigationDestination(
            icon: Icon(Icons.directions_car_filled_rounded),
            label: 'Catalogue',
          ),
          NavigationDestination(icon: Icon(Icons.tune_rounded), label: 'My Setups'),
          NavigationDestination(
            icon: Icon(Icons.sports_esports_rounded),
            label: 'Hardware',
          ),
        ],
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final List<dynamic> games;
  final List<dynamic> saved;
  final VoidCallback openCatalogue;
  final VoidCallback openSetups;

  const HomeScreen({
    super.key,
    required this.games,
    required this.saved,
    required this.openCatalogue,
    required this.openSetups,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 30),
      children: [
        Row(
          children: [
            Image.asset(
              'assets/branding/drivervault_icon.png',
              width: 72,
              height: 72,
            ),
            const SizedBox(width: 12),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'DriverVault',
                    style: TextStyle(
                      fontSize: 30,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'YOUR GAMES • YOUR SETUPS • ONE VAULT',
                    style: TextStyle(
                      fontSize: 9,
                      letterSpacing: 1.0,
                      color: Colors.white54,
                    ),
                  ),
                ],
              ),
            ),
            IconButton.filledTonal(
              onPressed: () {},
              icon: const Icon(Icons.settings_rounded),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const SectionTitle('YOUR GAMES'),
        const SizedBox(height: 12),
        if (games.isNotEmpty) ...[
          GameHero(game: games.first, onTap: openCatalogue),
          const SizedBox(height: 10),
          Row(
            children: [
              if (games.length > 1)
                Expanded(child: SmallGameCard(game: games[1], onTap: openCatalogue)),
              const SizedBox(width: 10),
              if (games.length > 2)
                Expanded(child: SmallGameCard(game: games[2], onTap: openCatalogue)),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              if (games.length > 3)
                Expanded(child: SmallGameCard(game: games[3], onTap: openCatalogue)),
              const SizedBox(width: 10),
              if (games.length > 4)
                Expanded(child: SmallGameCard(game: games[4], onTap: openCatalogue)),
            ],
          ),
        ],
        const SizedBox(height: 24),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text(
              'Quick Access',
              style: TextStyle(fontSize: 23, fontWeight: FontWeight.w900),
            ),
            TextButton(onPressed: openCatalogue, child: const Text('VIEW ALL')),
          ],
        ),
        Row(
          children: [
            Expanded(
              child: QuickTile(
                icon: Icons.directions_car_filled_rounded,
                title: 'Catalogue',
                subtitle: 'Find vehicles',
                onTap: openCatalogue,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: QuickTile(
                icon: Icons.tune_rounded,
                title: 'My Setups',
                subtitle: '${saved.length} saved',
                onTap: openSetups,
              ),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: QuickTile(
                icon: Icons.sports_esports_rounded,
                title: 'Hardware',
                subtitle: 'Profiles',
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class GameHero extends StatelessWidget {
  final dynamic game;
  final VoidCallback onTap;
  const GameHero({super.key, required this.game, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(22),
      child: Container(
        height: 205,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: gold.withValues(alpha: .55)),
          boxShadow: [
            BoxShadow(
              color: purple.withValues(alpha: .12),
              blurRadius: 22,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(21),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(game['art'], fit: BoxFit.cover),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xD9000000)],
                  ),
                ),
              ),
              Positioned(
                left: 15,
                bottom: 13,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: .72),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    '${(game['vehicles'] as List).length}  SETUPS',
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SmallGameCard extends StatelessWidget {
  final dynamic game;
  final VoidCallback onTap;
  const SmallGameCard({super.key, required this.game, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: AspectRatio(
        aspectRatio: 1.08,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(18),
          child: Stack(
            fit: StackFit.expand,
            children: [
              Image.asset(game['art'], fit: BoxFit.cover),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xB8000000)],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class QuickTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;
  const QuickTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(17),
      child: Container(
        height: 112,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: panel,
          borderRadius: BorderRadius.circular(17),
          border: Border.all(color: Colors.white.withValues(alpha: .05)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, color: purple),
            const Spacer(),
            Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
            Text(
              subtitle,
              style: const TextStyle(fontSize: 11, color: Colors.white54),
            ),
          ],
        ),
      ),
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String text;
  const SectionTitle(this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: purple,
        fontWeight: FontWeight.w900,
        letterSpacing: 1.8,
        fontSize: 13,
      ),
    );
  }
}

class CatalogueScreen extends StatefulWidget {
  final List<dynamic> games;
  final ValueChanged<Map<String, dynamic>> onSave;
  const CatalogueScreen({
    super.key,
    required this.games,
    required this.onSave,
  });

  @override
  State<CatalogueScreen> createState() => _CatalogueScreenState();
}

class _CatalogueScreenState extends State<CatalogueScreen> {
  String gameId = 'fh5';
  String query = '';

  @override
  Widget build(BuildContext context) {
    if (widget.games.isEmpty) {
      return const Center(child: CircularProgressIndicator());
    }

    final game = widget.games.firstWhere(
      (g) => g['id'] == gameId,
      orElse: () => widget.games.first,
    );
    final vehicles = (game['vehicles'] as List).where((v) {
      final haystack = '${v['year']} ${v['make']} ${v['model']}'.toLowerCase();
      return haystack.contains(query.toLowerCase());
    }).toList();

    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 18, 18, 30),
      children: [
        const Text(
          'Catalogue',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 3),
        const Text(
          'Browse games, vehicles and start building setups.',
          style: TextStyle(color: Colors.white60),
        ),
        const SizedBox(height: 15),
        TextField(
          onChanged: (value) => setState(() => query = value),
          decoration: InputDecoration(
            prefixIcon: const Icon(Icons.search_rounded),
            hintText: 'Search vehicles, make, model...',
            filled: true,
            fillColor: panel,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(15),
              borderSide: BorderSide.none,
            ),
          ),
        ),
        const SizedBox(height: 14),
        SizedBox(
          height: 74,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: widget.games.length,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              final g = widget.games[index];
              final selected = g['id'] == gameId;
              return GestureDetector(
                onTap: () => setState(() => gameId = g['id']),
                child: Container(
                  width: 92,
                  padding: const EdgeInsets.all(4),
                  decoration: BoxDecoration(
                    color: panel,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                      color: selected ? purple : Colors.white10,
                      width: selected ? 2 : 1,
                    ),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset(g['art'], fit: BoxFit.cover),
                  ),
                ),
              );
            },
          ),
        ),
        const SizedBox(height: 18),
        Text(
          '${vehicles.length} vehicles',
          style: const TextStyle(color: Colors.white60),
        ),
        const SizedBox(height: 8),
        if (vehicles.isEmpty)
          const EmptyPanel(
            'No starter vehicles loaded for this game yet.\nThe remote catalogue is the next data milestone.',
          )
        else
          ...vehicles.map(
            (v) => VehicleRow(
              vehicle: v,
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => VehicleScreen(
                    game: game,
                    vehicle: v,
                    onSave: widget.onSave,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class VehicleRow extends StatelessWidget {
  final dynamic vehicle;
  final VoidCallback onTap;
  const VehicleRow({super.key, required this.vehicle, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: panel,
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        onTap: onTap,
        contentPadding: const EdgeInsets.all(12),
        leading: Container(
          width: 76,
          height: 62,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            gradient: const LinearGradient(colors: [Color(0xFF371654), Color(0xFF7B3517)]),
          ),
          child: const Icon(Icons.directions_car_filled_rounded, size: 36),
        ),
        title: Text(
          '${vehicle['make']} ${vehicle['model']} ${vehicle['year']}'.trim(),
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Wrap(
            spacing: 5,
            children: [
              SpecChip(vehicle['class']),
              if ((vehicle['pi'] ?? '').toString().isNotEmpty)
                SpecChip(vehicle['pi']),
              SpecChip(vehicle['drive']),
            ],
          ),
        ),
        trailing: const Icon(Icons.chevron_right_rounded),
      ),
    );
  }
}

class SpecChip extends StatelessWidget {
  final dynamic value;
  const SpecChip(this.value, {super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: purple.withValues(alpha: .22),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        '$value',
        style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w800),
      ),
    );
  }
}

class VehicleScreen extends StatefulWidget {
  final dynamic game;
  final dynamic vehicle;
  final ValueChanged<Map<String, dynamic>> onSave;
  const VehicleScreen({
    super.key,
    required this.game,
    required this.vehicle,
    required this.onSave,
  });

  @override
  State<VehicleScreen> createState() => _VehicleScreenState();
}

class _VehicleScreenState extends State<VehicleScreen> {
  final List<Map<String, String>> examples = const [
    {'name': 'Road / Street', 'note': 'Balanced road setup for general driving.'},
    {'name': 'Drift', 'note': 'Angle focused drift setup.'},
    {'name': 'Race', 'note': 'Grip setup for circuit racing.'},
  ];

  @override
  Widget build(BuildContext context) {
    final v = widget.vehicle;
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.only(bottom: 30),
          children: [
            Stack(
              children: [
                Image.asset(
                  widget.game['art'],
                  width: double.infinity,
                  height: 245,
                  fit: BoxFit.cover,
                ),
                Container(
                  height: 245,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.transparent, bg],
                    ),
                  ),
                ),
                Positioned(
                  top: 12,
                  left: 12,
                  child: IconButton.filledTonal(
                    onPressed: () => Navigator.pop(context),
                    icon: const Icon(Icons.arrow_back),
                  ),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 0, 18, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${v['make']} ${v['model']} ${v['year']}'.trim(),
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    children: [
                      SpecChip(v['class']),
                      if ((v['pi'] ?? '').toString().isNotEmpty) SpecChip(v['pi']),
                      SpecChip(v['drive']),
                    ],
                  ),
                  const SizedBox(height: 22),
                  const SectionTitle('MY SETUPS'),
                  const SizedBox(height: 10),
                  ...examples.map(
                    (s) => Card(
                      color: panel,
                      child: ListTile(
                        leading: Container(
                          width: 64,
                          decoration: BoxDecoration(
                            color: panel2,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: const Icon(Icons.tune_rounded, color: purple),
                        ),
                        title: Text(
                          s['name']!,
                          style: const TextStyle(fontWeight: FontWeight.w900),
                        ),
                        subtitle: Text(s['note']!),
                        trailing: const Icon(Icons.more_vert),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      style: FilledButton.styleFrom(
                        backgroundColor: const Color(0xFF6D16B8),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                      onPressed: () => Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (_) => EditSetupScreen(
                            game: widget.game['name'],
                            vehicle: '${v['make']} ${v['model']} ${v['year']}'.trim(),
                            onSave: widget.onSave,
                          ),
                        ),
                      ),
                      icon: const Icon(Icons.add),
                      label: const Text('Create New Setup'),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class EditSetupScreen extends StatefulWidget {
  final String game;
  final String vehicle;
  final ValueChanged<Map<String, dynamic>> onSave;
  const EditSetupScreen({
    super.key,
    required this.game,
    required this.vehicle,
    required this.onSave,
  });

  @override
  State<EditSetupScreen> createState() => _EditSetupScreenState();
}

class _EditSetupScreenState extends State<EditSetupScreen> {
  final name = TextEditingController(text: 'Track / Grip');
  final description = TextEditingController();
  final power = TextEditingController();
  final weight = TextEditingController();
  String type = 'Race';
  String drive = 'RWD';
  String transmission = 'Manual';
  String finish = 'Solid';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('New Setup', style: TextStyle(fontWeight: FontWeight.w900)),
            Text(
              widget.vehicle,
              style: const TextStyle(fontSize: 11, color: Colors.white60),
            ),
          ],
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 30),
        children: [
          const SectionTitle('SETUP DETAILS'),
          const SizedBox(height: 10),
          Field(controller: name, label: 'Setup Name'),
          Field(controller: description, label: 'Description (optional)', lines: 3),
          const SizedBox(height: 12),
          const Text('Setup Type', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 8),
          Wrap(
            spacing: 7,
            children: ['Road', 'Drift', 'Race', 'Drag']
                .map(
                  (e) => ChoiceChip(
                    label: Text(e),
                    selected: type == e,
                    onSelected: (_) => setState(() => type = e),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 22),
          const SectionTitle('PERFORMANCE INFO'),
          const SizedBox(height: 10),
          Field(controller: power, label: 'Power (bhp)'),
          Field(controller: weight, label: 'Weight (kg)'),
          const SizedBox(height: 8),
          const Text('Drivetrain', style: TextStyle(color: Colors.white70)),
          Wrap(
            spacing: 7,
            children: ['FWD', 'RWD', 'AWD']
                .map(
                  (e) => ChoiceChip(
                    label: Text(e),
                    selected: drive == e,
                    onSelected: (_) => setState(() => drive = e),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 10),
          const Text('Transmission', style: TextStyle(color: Colors.white70)),
          Wrap(
            spacing: 7,
            children: ['Manual', 'Automatic']
                .map(
                  (e) => ChoiceChip(
                    label: Text(e),
                    selected: transmission == e,
                    onSelected: (_) => setState(() => transmission = e),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 22),
          const SectionTitle('COLOUR / FINISH'),
          const SizedBox(height: 8),
          Wrap(
            spacing: 7,
            runSpacing: 7,
            children: ['Solid', 'Matte', 'Metallic', 'Pearlescent', 'Two-tone']
                .map(
                  (e) => ChoiceChip(
                    label: Text(e),
                    selected: finish == e,
                    onSelected: (_) => setState(() => finish = e),
                  ),
                )
                .toList(),
          ),
          const SizedBox(height: 28),
          FilledButton.icon(
            style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFF7218BF),
              padding: const EdgeInsets.symmetric(vertical: 16),
            ),
            onPressed: () {
              widget.onSave({
                'game': widget.game,
                'vehicle': widget.vehicle,
                'title': name.text,
                'description': description.text,
                'type': type,
                'power': power.text,
                'weight': weight.text,
                'drive': drive,
                'transmission': transmission,
                'finish': finish,
              });
              Navigator.popUntil(context, (route) => route.isFirst);
            },
            icon: const Icon(Icons.check),
            label: const Text('Save Setup'),
          ),
        ],
      ),
    );
  }
}

class Field extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final int lines;
  const Field({
    super.key,
    required this.controller,
    required this.label,
    this.lines = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: controller,
        maxLines: lines,
        decoration: InputDecoration(
          labelText: label,
          filled: true,
          fillColor: panel,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
        ),
      ),
    );
  }
}

class SetupsScreen extends StatelessWidget {
  final List<dynamic> saved;
  final ValueChanged<dynamic> onDelete;
  const SetupsScreen({
    super.key,
    required this.saved,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text(
          'My Setups',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 4),
        const Text(
          'Every saved build in one place.',
          style: TextStyle(color: Colors.white60),
        ),
        const SizedBox(height: 18),
        if (saved.isEmpty)
          const EmptyPanel('No setups saved yet.')
        else
          ...saved.reversed.map(
            (s) => Card(
              color: panel,
              child: ListTile(
                leading: const Icon(Icons.tune_rounded, color: purple),
                title: Text(
                  s['title'] ?? 'Setup',
                  style: const TextStyle(fontWeight: FontWeight.w900),
                ),
                subtitle: Text('${s['game']}\n${s['vehicle']}'),
                isThreeLine: true,
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => onDelete(s),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class HardwareScreen extends StatefulWidget {
  const HardwareScreen({super.key});
  @override
  State<HardwareScreen> createState() => _HardwareScreenState();
}

class _HardwareScreenState extends State<HardwareScreen> {
  List<dynamic> hardware = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    hardware = jsonDecode(prefs.getString('dv_hw') ?? '[]');
    if (mounted) setState(() {});
  }

  Future<void> add() async {
    final name = TextEditingController();
    final notes = TextEditingController();
    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Add Hardware'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Field(controller: name, label: 'Name'),
            Field(controller: notes, label: 'Settings / notes', lines: 3),
          ],
        ),
        actions: [
          FilledButton(
            onPressed: () {
              hardware.add({'name': name.text, 'notes': notes.text});
              Navigator.pop(dialogContext);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('dv_hw', jsonEncode(hardware));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton(
        onPressed: add,
        child: const Icon(Icons.add),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'Hardware',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
          ),
          const SizedBox(height: 4),
          const Text(
            'Wheel bases • wheels • pedals • controllers',
            style: TextStyle(color: gold),
          ),
          const SizedBox(height: 18),
          if (hardware.isEmpty)
            const EmptyPanel('No hardware profiles yet.')
          else
            ...hardware.map(
              (h) => Card(
                color: panel,
                child: ListTile(
                  leading: const Icon(Icons.sports_esports_rounded, color: gold),
                  title: Text(h['name'] ?? ''),
                  subtitle: Text(h['notes'] ?? ''),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class EmptyPanel extends StatelessWidget {
  final String text;
  const EmptyPanel(this.text, {super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: panel,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Text(text, style: const TextStyle(color: Colors.white60)),
    );
  }
}
