#!/usr/bin/env python3
import json, re, sys, urllib.request, urllib.parse, html, unicodedata, difflib
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from urllib.parse import quote

CAT=Path("assets/catalog/catalog.json")
data=json.loads(CAT.read_text(encoding="utf-8"))

MAKES=sorted([
"Abarth","Acura","Alfa Romeo","Alpine","Alumi Craft","AMC","AMG Transport Dynamics",
"Apollo","Ariel","Ascari","Aston Martin","ATS","Audi","Austin-Healey","Auto Union",
"Automobili Pininfarina","Autozam","BAC","Bentley","BMW","Brabham","Bugatti","Buick",
"Cadillac","Can-Am","Casey Currie Motorsports","Caterham","Chevrolet","Citroën","CUPRA",
"Czinger","Datsun","DeBerti","DeLorean","Dodge","Donkervoort","DS Automobiles","Eagle",
"Exomotive","Ferrari","FIAT","Ford","Formula Drift","Forsberg Racing","Funco","GMC",
"Hennessey","Holden","Honda","Hoonigan","Hot Wheels","HSV","HUMMER","Hyundai","Infiniti",
"International","Italdesign","Jaguar","Jeep","Koenigsegg","KTM","Lamborghini","Lancia",
"Land Rover","Lexus","Lincoln","Local Motors","Lola","Lotus","Lucid","Lynk & Co","Maserati",
"Mazda","McLaren","Mercedes-AMG","Mercedes-Benz","Mercury","MG","MINI","Mitsubishi",
"Morgan","Morris","Mosler","Napier","NIO","Nissan","Noble","Oldsmobile","Opel","Pagani",
"Peel","Penhall","Peugeot","Plymouth","Polaris","Pontiac","Porsche","RAESR","Radical",
"Renault","Rimac","Rivian","Rossion","RUF","Saleen","Schuppan","Shelby","Sierra Cars",
"Spania GTA","Subaru","Toyota","TVR","Ultima","Vauxhall","Volkswagen","Volvo","W Motors",
"Wuling","Xpeng","Zenvo"
], key=len, reverse=True)

def fetch(url):
    req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0 DriverVault/1.0"})
    with urllib.request.urlopen(req,timeout=45) as r:
        return r.read().decode("utf-8","replace")

def strip_tags(x):
    return re.sub(r"\s+"," ",html.unescape(re.sub(r"<[^>]+>","",x))).strip()

def split_make(name):
    for make in MAKES:
        if name == make or name.startswith(make+" "):
            return make, name[len(make):].strip()
    parts=name.split(" ",1)
    return (parts[0],parts[1] if len(parts)>1 else "")

def game(gid):
    return next(g for g in data["games"] if g["id"]==gid)


WIKI_API="https://commons.wikimedia.org/w/api.php"

def fetch_json_url(url, timeout=30):
    req=urllib.request.Request(url,headers={"User-Agent":"DriverVault/1.4 (vehicle catalogue image resolver)"})
    with urllib.request.urlopen(req,timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8","replace"))

def commons_image(make, model, year):
    # Search Commons for a real photograph. Prefer queries including the model year,
    # then fall back to make+model. Results are resolved to direct HTTPS thumbnail URLs.
    queries=[f'{year} {make} {model} automobile', f'{make} {model} car']
    for q in queries:
        params=urllib.parse.urlencode({
            'action':'query','generator':'search','gsrsearch':q+' filetype:bitmap',
            'gsrnamespace':'6','gsrlimit':'5','prop':'imageinfo','iiprop':'url|mime',
            'iiurlwidth':'800','format':'json','formatversion':'2'
        })
        try:
            root=fetch_json_url(WIKI_API+'?'+params,20)
            for page in root.get('query',{}).get('pages',[]):
                ii=(page.get('imageinfo') or [{}])[0]
                u=ii.get('thumburl') or ii.get('url') or ''
                mime=ii.get('mime','')
                if u.startswith('https://') and mime.startswith('image/'):
                    return u
        except Exception:
            pass
    return ''

def add_verified_images():
    # Resolve images at BUILD TIME. The app receives direct URLs only; it does not
    # search or depend on an image-search service at runtime.
    fh=game('fh5')['vehicles']
    resolved=0
    # Do a representative front-of-catalogue gate first so a build cannot pass with
    # the exact blank-card failure seen in v1.3.
    first=fh[:8]
    for v in first:
        u=commons_image(v.get('make',''),v.get('model',''),v.get('year',''))
        if u:
            v['image']=u; resolved+=1
    if sum(bool(v.get('image')) for v in first) < 6:
        raise RuntimeError('IMAGE PREFLIGHT FAILED: fewer than 6/8 first FH5 cars resolved')
    # Resolve the rest concurrently. Network misses remain explicit fallbacks, never fake matches.
    def resolve_one(pair):
        idx,v=pair
        return idx, commons_image(v.get('make',''),v.get('model',''),v.get('year',''))
    pairs=list(enumerate(fh[8:],8))
    checked=8
    with ThreadPoolExecutor(max_workers=12) as ex:
        futures=[ex.submit(resolve_one,p) for p in pairs]
        for fut in as_completed(futures):
            idx,u=fut.result(); checked+=1
            if u:
                fh[idx]['image']=u; resolved+=1
            if checked % 100 == 0: print(f'FH5 image resolver: {checked}/902 checked, {resolved} mapped')
    # Verify direct image bytes for the exact first four cars shown in the user's screenshot.
    ok=0
    for v in fh[:4]:
        try:
            req=urllib.request.Request(v['image'],headers={'User-Agent':'DriverVault/1.4'})
            with urllib.request.urlopen(req,timeout=20) as r:
                body=r.read(16384); ctype=r.headers.get('Content-Type','')
                if r.status==200 and ctype.startswith('image/') and len(body)>2000: ok+=1
        except Exception as e: print('Image byte check failed:',v.get('make'),v.get('model'),e)
    if ok != 4:
        raise RuntimeError(f'IMAGE BYTE PREFLIGHT FAILED: {ok}/4 screenshot cars returned real image bytes')
    print(f'FH5 images: {resolved}/902 mapped; FIRST 4 SCREENSHOT CARS = 4/4 LIVE')

def update_fh5():
    raw=fetch("https://forza.net/fh5cars")
    rows=re.findall(r"<tr[^>]*>(.*?)</tr>",raw,re.I|re.S)
    out=[]
    for row in rows:
        cells=[strip_tags(x) for x in re.findall(r"<td[^>]*>(.*?)</td>",row,re.I|re.S)]
        if len(cells)<6 or not re.match(r"^\d{4}\s",cells[0]): continue
        year,name=cells[0].split(" ",1)
        make,model=split_make(name)
        car_id=re.sub(r"\D","",cells[5])
        if not car_id: continue
        out.append({
          "id":f"fh5:{car_id}","year":year,"make":make,"model":model,
          "class":cells[1],"drive":"","collect":cells[2],"added":cells[3],
          "nickname":cells[4],"image":""
        })
    if len(out)!=902:
        raise RuntimeError(f"FH5 validation FAILED: expected 902, parsed {len(out)}")
    g=game("fh5"); g["vehicles"]=out; g["official_total"]=902
    g["source"]="https://forza.net/fh5cars"; g["verifiedAt"]="2026-09-27"
    print("FH5: 902/902 validated")

def update_gt7():
    raw=fetch("https://raw.githubusercontent.com/jbhoorasingh/gt7-datalogger/main/backend/app/data/cars.json")
    root=json.loads(raw); cars=root["cars"]; out=[]
    for cid,c in cars.items():
        name=(c.get("name") or "").strip()
        full=(c.get("full_name") or "").strip()
        make=(c.get("manufacturer") or "").strip()
        model=name or full
        # Official Gran Turismo car-list detail route uses the numeric vehicle id.
        image=f"https://www.gran-turismo.com/images/c/i1QHdbil7nGQk.jpg" if False else ""
        out.append({
          "id":f"gt7:{cid}","year":str(c.get("year") or ""),
          "make":make,"model":model,"class":str(c.get("category") or ""),
          "drive":str(c.get("drivetrain") or ""),"image":image
        })
    if len(out)<570:
        raise RuntimeError(f"GT7 validation FAILED: parsed only {len(out)}")
    g=game("gt7"); g["vehicles"]=out; g["official_total"]=len(out)
    g["source"]=root.get("meta",{}).get("source","Gran Turismo official car list")
    g["verifiedAt"]=root.get("meta",{}).get("generated","2026-09-27")
    print(f"GT7: {len(out)} vehicles validated")

update_fh5()
update_gt7()
add_verified_images()

# Hard validation for catalogues we have completed locally.
expected={"assetto":178,"snowrunner":116,"alaskan":19,"mudrunner":35}
for gid,n in expected.items():
    actual=len(game(gid)["vehicles"])
    if actual!=n: raise RuntimeError(f"{gid}: expected {n}, got {actual}")
    print(f"{gid}: {actual}/{n} validated")

data["version"]="1.4.0"
CAT.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
print("Catalogue validation complete.")
