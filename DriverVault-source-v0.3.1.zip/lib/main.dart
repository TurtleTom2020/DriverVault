import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
void main()=>runApp(const DV());
const bg=Color(0xff09080d),panel=Color(0xff17131f),purple=Color(0xff9b4dff),gold=Color(0xffffc62e);
class DV extends StatelessWidget{const DV({super.key});@override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,theme:ThemeData.dark(useMaterial3:true).copyWith(scaffoldBackgroundColor:bg,colorScheme:ColorScheme.fromSeed(seedColor:purple,brightness:Brightness.dark)),home:const Shell());}
class Shell extends StatefulWidget{const Shell({super.key});@override State<Shell> createState()=>_S();}
class _S extends State<Shell>{int tab=0;List games=[],saved=[];String scheme='Purple + Gold';Color get accent=>switch(scheme){'Blue'=>Colors.blueAccent,'Red'=>Colors.redAccent,'Green'=>Colors.greenAccent,'Copper'=>Colors.orangeAccent,_=>purple};
@override void initState(){super.initState();load();}Future<void> load()async{games=jsonDecode(await rootBundle.loadString('assets/catalog/catalog.json'))['games'];final p=await SharedPreferences.getInstance();saved=jsonDecode(p.getString('saved')??'[]');scheme=p.getString('scheme')??scheme;if(mounted)setState((){});}Future<void> persist()async{final p=await SharedPreferences.getInstance();await p.setString('saved',jsonEncode(saved));}
@override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:IndexedStack(index:tab,children:[home(),catalogue(),setups(),hardware()])),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[NavigationDestination(icon:Icon(Icons.home_outlined),label:'Home'),NavigationDestination(icon:Icon(Icons.directions_car_outlined),label:'Catalogue'),NavigationDestination(icon:Icon(Icons.tune),label:'My Setups'),NavigationDestination(icon:Icon(Icons.sports_esports_outlined),label:'Hardware')])); 
Widget head()=>Row(children:[ClipRRect(borderRadius:BorderRadius.circular(14),child:Image.asset('assets/branding/drivervault_icon.png',width:56,height:56)),const SizedBox(width:12),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('DriverVault',style:TextStyle(fontSize:27,fontWeight:FontWeight.w900)),Text('Your games. Your setups. All in one place.',style:TextStyle(color:Colors.white60,fontSize:12))])),IconButton(onPressed:theme,icon:const Icon(Icons.palette_outlined))]);
Widget home()=>ListView(padding:const EdgeInsets.all(18),children:[head(),const SizedBox(height:24),Text('YOUR GAMES',style:TextStyle(color:accent,fontWeight:FontWeight.bold,letterSpacing:1.4)),const SizedBox(height:10),SizedBox(height:120,child:ListView(scrollDirection:Axis.horizontal,children:games.map((g)=>Container(width:170,margin:const EdgeInsets.only(right:10),padding:const EdgeInsets.all(14),decoration:BoxDecoration(borderRadius:BorderRadius.circular(18),gradient:LinearGradient(colors:[accent.withValues(alpha:.35),panel]),border:Border.all(color:gold.withValues(alpha:.35))),child:Column(mainAxisAlignment:MainAxisAlignment.end,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(g['short'],style:const TextStyle(fontSize:22,fontWeight:FontWeight.w900)),Text(g['name'],maxLines:2,style:const TextStyle(color:Colors.white70,fontSize:12))]))).toList())),const SizedBox(height:25),const Text('Quick access',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),Row(children:[Expanded(child:quick(Icons.directions_car,'Catalogue','Find a vehicle',()=>setState(()=>tab=1))),const SizedBox(width:10),Expanded(child:quick(Icons.tune,'My Setups','${saved.length} saved',()=>setState(()=>tab=2)))]),const SizedBox(height:25),const Text('Recent setups',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),const SizedBox(height:10),if(saved.isEmpty)box(const Text('Nothing saved yet. Choose a game, find a vehicle and build your first setup.',style:TextStyle(color:Colors.white60)))else ...saved.reversed.take(3).map((s)=>Card(color:panel,child:ListTile(leading:Icon(Icons.bookmark,color:accent),title:Text(s['title']),subtitle:Text('${s['game']} • ${s['vehicle']}'))))]);
Widget quick(IconData i,String a,String b,VoidCallback f)=>InkWell(onTap:f,child:box(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(i,color:accent),const SizedBox(height:12),Text(a,style:const TextStyle(fontWeight:FontWeight.bold)),Text(b,style:const TextStyle(color:Colors.white54,fontSize:12))])));
Widget box(Widget x)=>Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:panel,borderRadius:BorderRadius.circular(18)),child:x);
Widget catalogue()=>Catalogue(games:games,accent:accent,onSave:(x){saved.add(x);persist();setState((){});});
Widget setups()=>ListView(padding:const EdgeInsets.all(18),children:[const Text('My Setups',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const SizedBox(height:14),if(saved.isEmpty)const Text('No setups saved yet.',style:TextStyle(color:Colors.white60))else ...saved.map((s)=>Card(color:panel,child:ListTile(leading:Icon(Icons.tune,color:accent),title:Text(s['title']),subtitle:Text('${s['game']}\n${s['vehicle']}'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){saved.remove(s);persist();setState((){});}))))]);
Widget hardware()=>const Hardware();
void theme()=>showModalBottomSheet(context:context,backgroundColor:panel,builder:(c)=>Padding(padding:const EdgeInsets.all(20),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('Appearance',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:12),Wrap(spacing:8,children:['Purple + Gold','Blue','Red','Green','Copper'].map((e)=>ChoiceChip(label:Text(e),selected:scheme==e,onSelected:(_)async{scheme=e;final p=await SharedPreferences.getInstance();await p.setString('scheme',e);setState((){});if(c.mounted)Navigator.pop(c);})).toList()),const SizedBox(height:16),const Text('Finish engine: Solid • Matte • Metallic • Pearlescent • Two-tone',style:TextStyle(color:Colors.white60))])));}
class Catalogue extends StatefulWidget{final List games;final Color accent;final ValueChanged<Map<String,dynamic>> onSave;const Catalogue({super.key,required this.games,required this.accent,required this.onSave});@override State<Catalogue> createState()=>_C();}
class _C extends State<Catalogue>{String game='fh5',q='';@override Widget build(BuildContext c){if(widget.games.isEmpty)return const Center(child:CircularProgressIndicator());final g=widget.games.firstWhere((x)=>x['id']==game,orElse:()=>widget.games.first);final cars=(g['vehicles'] as List).where((v)=>('${v[0]} ${v[1]}').toLowerCase().contains(q.toLowerCase())).toList();return ListView(padding:const EdgeInsets.all(18),children:[const Text('Catalogue',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),const Text('Game → vehicle → setup',style:TextStyle(color:Colors.white60)),const SizedBox(height:14),SizedBox(height:42,child:ListView(scrollDirection:Axis.horizontal,children:widget.games.map((x)=>Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(x['short']),selected:game==x['id'],onSelected:(_)=>setState(()=>game=x['id'])))).toList())),const SizedBox(height:12),TextField(onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:'Search vehicles…',filled:true,fillColor:panel,border:OutlineInputBorder(borderRadius:BorderRadius.circular(16),borderSide:BorderSide.none))),const SizedBox(height:12),if(cars.isEmpty)const Padding(padding:EdgeInsets.all(20),child:Text('No catalogue entries yet for this game. Catalogue updates remain separate from your personal setups.',style:TextStyle(color:Colors.white60)))else ...cars.map((v)=>Card(color:panel,child:ListTile(leading:Icon(Icons.directions_car,color:widget.accent),title:Text('${v[0]} ${v[1]}'.trim()),subtitle:Text(g['name']),trailing:const Icon(Icons.chevron_right),onTap:()=>edit(c,g['name'],v[1]))))]);}
void edit(BuildContext c,String game,String vehicle){final title=TextEditingController(text:'General Setup'),notes=TextEditingController();showModalBottomSheet(context:c,isScrollControlled:true,backgroundColor:panel,builder:(c)=>Padding(padding:EdgeInsets.fromLTRB(20,20,20,MediaQuery.of(c).viewInsets.bottom+20),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(vehicle,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold)),Text(game,style:TextStyle(color:widget.accent)),TextField(controller:title,decoration:const InputDecoration(labelText:'Setup name')),TextField(controller:notes,maxLines:4,decoration:const InputDecoration(labelText:'Tune / settings / notes')),const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:(){widget.onSave({'game':game,'vehicle':vehicle,'title':title.text,'notes':notes.text});Navigator.pop(c);},icon:const Icon(Icons.save),label:const Text('Save to DriverVault')))])));}}
class Hardware extends StatefulWidget {
  const Hardware({super.key});
  @override
  State<Hardware> createState() => _H();
}

class _H extends State<Hardware> {
  List items = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    items = jsonDecode(p.getString('hardware') ?? '[]');
    if (mounted) setState(() {});
  }

  Future<void> add() async {
    final n = TextEditingController();
    final x = TextEditingController();
    await showDialog(
      context: context,
      builder: (c) => AlertDialog(
        title: const Text('Add hardware'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: n, decoration: const InputDecoration(labelText: 'Name')),
            TextField(controller: x, decoration: const InputDecoration(labelText: 'Settings / notes')),
          ],
        ),
        actions: [
          FilledButton(
            onPressed: () {
              items.add({'name': n.text, 'notes': x.text});
              Navigator.pop(c);
            },
            child: const Text('Save'),
          )
        ],
      ),
    );
    final p = await SharedPreferences.getInstance();
    await p.setString('hardware', jsonEncode(items));
    setState(() {});
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        backgroundColor: Colors.transparent,
        floatingActionButton: FloatingActionButton(onPressed: add, child: const Icon(Icons.add)),
        body: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text('Hardware', style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
            const Text('Wheel, controller and base profiles stay separate from vehicle tunes.', style: TextStyle(color: Colors.white60)),
            const SizedBox(height: 14),
            if (items.isEmpty)
              const Text('No hardware profiles yet.', style: TextStyle(color: Colors.white60))
            else
              ...items.map((h) => Card(
                    color: panel,
                    child: ListTile(
                      leading: const Icon(Icons.sports_esports),
                      title: Text(h['name']),
                      subtitle: Text(h['notes']),
                    ),
                  )),
          ],
        ),
      );
}
