
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

const bg=Color(0xff07060b), card=Color(0xff10101a), card2=Color(0xff171724);
const purple=Color(0xffb115ff), gold=Color(0xffffc438);

void main()=>runApp(const DriverVault());
class DriverVault extends StatelessWidget{
 const DriverVault({super.key});
 @override Widget build(BuildContext c)=>MaterialApp(
  debugShowCheckedModeBanner:false,title:'DriverVault',
  theme:ThemeData.dark(useMaterial3:true).copyWith(
   scaffoldBackgroundColor:bg,
   colorScheme:ColorScheme.fromSeed(seedColor:purple,brightness:Brightness.dark),
   appBarTheme:const AppBarTheme(backgroundColor:bg,surfaceTintColor:Colors.transparent)),
  home:const Shell());
}

class Shell extends StatefulWidget{const Shell({super.key});@override State<Shell> createState()=>_Shell();}
class _Shell extends State<Shell>{
 int tab=0; List<dynamic> games=[]; List<dynamic> setups=[];
 @override void initState(){super.initState();load();}
 Future<void> load()async{
  final data=jsonDecode(await rootBundle.loadString('assets/catalog/catalog.json'));
  final p=await SharedPreferences.getInstance();
  games=data['games']; setups=jsonDecode(p.getString('setups')??'[]');
  if(mounted)setState((){});
 }
 Future<void> persist()async{final p=await SharedPreferences.getInstance();await p.setString('setups',jsonEncode(setups));}
 void add(Map<String,dynamic> s){setups.add(s);persist();setState((){});}
 @override Widget build(BuildContext c)=>Scaffold(
  body:SafeArea(child:IndexedStack(index:tab,children:[
   Home(games:games,setups:setups,onCatalogue:()=>setState(()=>tab=1),onSetups:()=>setState(()=>tab=2)),
   Catalogue(games:games,onSave:add),
   MySetups(items:setups,onDelete:(x){setups.remove(x);persist();setState((){});}),
   const Hardware(),
  ])),
  bottomNavigationBar:NavigationBar(height:72,backgroundColor:const Color(0xff0b0910),indicatorColor:const Color(0xff65209a),
   selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[
    NavigationDestination(icon:Icon(Icons.home_rounded),label:'Home'),
    NavigationDestination(icon:Icon(Icons.directions_car_filled_rounded),label:'Catalogue'),
    NavigationDestination(icon:Icon(Icons.tune_rounded),label:'My Setups'),
    NavigationDestination(icon:Icon(Icons.sports_esports_rounded),label:'Hardware')]));
}

class Home extends StatelessWidget{
 final List games,setups; final VoidCallback onCatalogue,onSetups;
 const Home({super.key,required this.games,required this.setups,required this.onCatalogue,required this.onSetups});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.fromLTRB(18,12,18,28),children:[
  Row(children:[
   Image.asset('assets/branding/drivervault_icon.png',width:82,height:82),
   const SizedBox(width:10),
   const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text.rich(TextSpan(children:[TextSpan(text:'Driver',style:TextStyle(color:Colors.white)),TextSpan(text:'Vault',style:TextStyle(color:gold))]),
     style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,letterSpacing:-1)),
    Text('YOUR GAMES • YOUR SETUPS • ONE VAULT',style:TextStyle(fontSize:8.5,color:Colors.white60,letterSpacing:.8))])),
   IconButton.filledTonal(onPressed:(){},icon:const Icon(Icons.settings_rounded))]),
  const SizedBox(height:22),
  Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Label('YOUR GAMES'),TextButton(onPressed:onCatalogue,child:const Text('VIEW ALL ›'))]),
  if(games.isNotEmpty) HeroGame(game:games[0],onTap:onCatalogue),
  const SizedBox(height:9),
  if(games.length>2) Row(children:[Expanded(child:GameTile(game:games[1],onTap:onCatalogue)),const SizedBox(width:9),Expanded(child:GameTile(game:games[2],onTap:onCatalogue))]),
  const SizedBox(height:9),
  if(games.length>4) Row(children:[Expanded(child:GameTile(game:games[3],onTap:onCatalogue)),const SizedBox(width:9),Expanded(child:GameTile(game:games[4],onTap:onCatalogue))]),
  const SizedBox(height:9),
  if(games.length>6) Row(children:[Expanded(child:GameTile(game:games[5],onTap:onCatalogue)),const SizedBox(width:9),Expanded(child:GameTile(game:games[6],onTap:onCatalogue))]),
  const SizedBox(height:18),const Label('QUICK ACCESS'),const SizedBox(height:10),
  Row(children:[
   Expanded(child:Quick(icon:Icons.directions_car_filled_rounded,title:'Catalogue',sub:'Find vehicles',tap:onCatalogue)),
   const SizedBox(width:8),Expanded(child:Quick(icon:Icons.tune_rounded,title:'My Setups',sub:'View & manage',tap:onSetups)),
   const SizedBox(width:8),const Expanded(child:Quick(icon:Icons.sports_esports_rounded,title:'Hardware',sub:'Manage profiles')),
   const SizedBox(width:8),const Expanded(child:Quick(icon:Icons.star_rounded,title:'Favourites',sub:'Your saved cars'))]),
 ]);
}
class Label extends StatelessWidget{final String s;const Label(this.s,{super.key});@override Widget build(BuildContext c)=>Text(s,style:const TextStyle(color:purple,fontSize:13,fontWeight:FontWeight.w900,letterSpacing:1.5));}
class HeroGame extends StatelessWidget{final dynamic game;final VoidCallback onTap;const HeroGame({super.key,required this.game,required this.onTap});
 @override Widget build(BuildContext c)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(18),child:Container(height:188,decoration:BoxDecoration(borderRadius:BorderRadius.circular(18),border:Border.all(color:gold.withValues(alpha:.55))),child:ClipRRect(borderRadius:BorderRadius.circular(17),child:Image.asset(game['art'],fit:BoxFit.cover,filterQuality:FilterQuality.high))));}
class GameTile extends StatelessWidget{final dynamic game;final VoidCallback onTap;const GameTile({super.key,required this.game,required this.onTap});
 @override Widget build(BuildContext c)=>InkWell(onTap:onTap,borderRadius:BorderRadius.circular(15),child:AspectRatio(aspectRatio:1.28,child:ClipRRect(borderRadius:BorderRadius.circular(15),child:Image.asset(game['art'],fit:BoxFit.cover,filterQuality:FilterQuality.high))));}
class Quick extends StatelessWidget{final IconData icon;final String title,sub;final VoidCallback? tap;const Quick({super.key,required this.icon,required this.title,required this.sub,this.tap});
 @override Widget build(BuildContext c)=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(12),child:Container(height:88,padding:const EdgeInsets.all(10),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(12),border:Border.all(color:Colors.white10)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:purple,size:25),const Spacer(),Text(title,maxLines:1,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:12)),Text(sub,maxLines:1,style:const TextStyle(fontSize:9,color:Colors.white54))])));}
class Catalogue extends StatefulWidget{final List games;final ValueChanged<Map<String,dynamic>> onSave;const Catalogue({super.key,required this.games,required this.onSave});@override State<Catalogue> createState()=>_Catalogue();}
class _Catalogue extends State<Catalogue>{
 String q='';
 @override Widget build(BuildContext c){final filtered=widget.games.where((g)=>g['name'].toString().toLowerCase().contains(q.toLowerCase())).toList();
 return ListView(padding:const EdgeInsets.fromLTRB(18,15,18,28),children:[
  const Text('Catalogue',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),const Text('Select a game to browse vehicles.',style:TextStyle(color:Colors.white60,fontSize:12)),const SizedBox(height:14),
  TextField(onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:'Search games...',filled:true,fillColor:card,border:OutlineInputBorder(borderRadius:BorderRadius.circular(10),borderSide:BorderSide.none))),
  const SizedBox(height:12),
  ...filtered.map((g)=>GameRow(game:g,onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>VehicleCatalogue(game:g,onSave:widget.onSave))))),
 ]);}
}
class GameRow extends StatelessWidget{final dynamic game;final VoidCallback onTap;const GameRow({super.key,required this.game,required this.onTap});
 @override Widget build(BuildContext c){final n=(game['vehicles'] as List).length;final official=game['official_total'];return InkWell(onTap:onTap,child:Container(height:76,margin:const EdgeInsets.only(bottom:2),padding:const EdgeInsets.all(8),decoration:const BoxDecoration(border:Border(bottom:BorderSide(color:Colors.white12))),child:Row(children:[
  SizedBox(width:86,child:ClipRRect(borderRadius:BorderRadius.circular(7),child:Image.asset(game['art'],fit:BoxFit.cover,filterQuality:FilterQuality.high))),const SizedBox(width:12),
  Expanded(child:Column(mainAxisAlignment:MainAxisAlignment.center,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(game['name'],style:const TextStyle(fontWeight:FontWeight.w800)),Text(official!=null?'$n bundled • $official official':'$n vehicles',style:const TextStyle(color:Colors.white60,fontSize:11))])),const Icon(Icons.chevron_right)])));}
}
class VehicleCatalogue extends StatefulWidget{final dynamic game;final ValueChanged<Map<String,dynamic>> onSave;const VehicleCatalogue({super.key,required this.game,required this.onSave});@override State<VehicleCatalogue> createState()=>_VehicleCatalogue();}
class _VehicleCatalogue extends State<VehicleCatalogue>{String q='';bool grid=true;
 @override Widget build(BuildContext c){final vs=(widget.game['vehicles'] as List).where((v)=>('${v['year']} ${v['make']} ${v['model']}').toLowerCase().contains(q.toLowerCase())).toList();
 return Scaffold(appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(widget.game['name'],style:const TextStyle(fontWeight:FontWeight.w900,fontSize:19)),Text('${vs.length} vehicles',style:const TextStyle(fontSize:10,color:Colors.white60))])),
 body:ListView(padding:const EdgeInsets.all(14),children:[
  TextField(onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:'Search vehicles...',filled:true,fillColor:card,border:OutlineInputBorder(borderRadius:BorderRadius.circular(10),borderSide:BorderSide.none))),const SizedBox(height:10),
  Row(children:[const Chip(label:Text('All Makes')),const SizedBox(width:6),const Chip(label:Text('All Classes')),const Spacer(),IconButton.filledTonal(onPressed:()=>setState(()=>grid=!grid),icon:Icon(grid?Icons.grid_view:Icons.list))]),
  if(vs.isEmpty) Padding(padding:const EdgeInsets.all(20),child:Text(widget.game['source']=='Catalogue expansion queued'?'Catalogue source is queued for the next data import.':'No matching vehicles.',style:const TextStyle(color:Colors.white60)))
  else if(grid) GridView.builder(shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:2,childAspectRatio:.9,crossAxisSpacing:8,mainAxisSpacing:8),itemCount:vs.length,itemBuilder:(c,i)=>VehicleCard(v:vs[i],tap:()=>openVehicle(c,vs[i])))
  else ...vs.map((v)=>ListTile(title:Text('${v['make']} ${v['model']}'),subtitle:Text(v['year']),trailing:const Icon(Icons.chevron_right),onTap:()=>openVehicle(c,v)))
 ]));}
 void openVehicle(BuildContext c,dynamic v)=>Navigator.push(c,MaterialPageRoute(builder:(_)=>VehiclePage(game:widget.game,v:v,onSave:widget.onSave)));
}
class VehicleCard extends StatelessWidget{final dynamic v;final VoidCallback tap;const VehicleCard({super.key,required this.v,required this.tap});
 @override Widget build(BuildContext c)=>InkWell(onTap:tap,borderRadius:BorderRadius.circular(12),child:Container(decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(12),border:Border.all(color:Colors.white10)),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
  Expanded(child:Container(decoration:const BoxDecoration(borderRadius:BorderRadius.vertical(top:Radius.circular(11)),gradient:LinearGradient(colors:[Color(0xff1d2335),Color(0xff351447)])),child:const Center(child:Icon(Icons.directions_car_filled_rounded,size:54,color:Colors.white70)))),
  Padding(padding:const EdgeInsets.all(8),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text('${v['make']} ${v['model']}'.trim(),maxLines:2,style:const TextStyle(fontWeight:FontWeight.w800,fontSize:12)),Text(v['year'],style:const TextStyle(color:Colors.white60,fontSize:10))]))])));}
class VehiclePage extends StatelessWidget{final dynamic game,v;final ValueChanged<Map<String,dynamic>> onSave;const VehiclePage({super.key,required this.game,required this.v,required this.onSave});
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Text('${v['make']} ${v['model']}'.trim())),body:ListView(children:[
  Container(height:280,decoration:const BoxDecoration(gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Color(0xff283247),bg])),child:const Icon(Icons.directions_car_filled_rounded,size:150,color:Colors.white70)),
  Padding(padding:const EdgeInsets.all(18),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   Text('${v['make']} ${v['model']}'.trim(),style:const TextStyle(fontSize:26,fontWeight:FontWeight.w900)),Text(v['year'],style:const TextStyle(color:Colors.white60)),const SizedBox(height:20),
   const Row(children:[Expanded(child:Center(child:Text('Overview'))),Expanded(child:Center(child:Text('My Setups',style:TextStyle(color:purple)))),Expanded(child:Center(child:Text('Details')))]),const Divider(color:purple),
   const SizedBox(height:10),Container(padding:const EdgeInsets.all(16),decoration:BoxDecoration(color:card,borderRadius:BorderRadius.circular(12)),child:const Text('No saved setups for this vehicle yet.',style:TextStyle(color:Colors.white60))),
   const SizedBox(height:16),SizedBox(width:double.infinity,child:FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:const Color(0xff7113bd),padding:const EdgeInsets.all(16)),onPressed:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>EditSetup(game:game['name'],vehicle:'${v['make']} ${v['model']} ${v['year']}'.trim(),onSave:onSave))),icon:const Icon(Icons.add),label:const Text('Create New Setup')))
  ]))]));}
class EditSetup extends StatefulWidget{final String game,vehicle;final ValueChanged<Map<String,dynamic>> onSave;const EditSetup({super.key,required this.game,required this.vehicle,required this.onSave});@override State<EditSetup> createState()=>_EditSetup();}
class _EditSetup extends State<EditSetup>{final name=TextEditingController(text:'Track / Grip'),desc=TextEditingController();String type='Race',drive='RWD',trans='Manual',tyres='Semi-Slick';double front=5,rear=7,ride=-10,stiff=8;
 @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('New Setup'),Text(widget.vehicle,style:const TextStyle(fontSize:10,color:Colors.white60))])),body:ListView(padding:const EdgeInsets.all(16),children:[
  const Label('SETUP DETAILS'),field(name,'Setup Name'),field(desc,'Description (optional)',3),const Text('Setup Type'),Wrap(spacing:8,children:['Road','Drift','Race','Drag'].map((x)=>ChoiceChip(label:Text(x),selected:type==x,onSelected:(_)=>setState(()=>type=x))).toList()),
  const SizedBox(height:18),const Label('PERFORMANCE INFO'),const SizedBox(height:8),const Text('Drivetrain'),Wrap(spacing:8,children:['FWD','RWD','AWD'].map((x)=>ChoiceChip(label:Text(x),selected:drive==x,onSelected:(_)=>setState(()=>drive=x))).toList()),
  const Text('Transmission'),Wrap(spacing:8,children:['Manual','Automatic'].map((x)=>ChoiceChip(label:Text(x),selected:trans==x,onSelected:(_)=>setState(()=>trans=x))).toList()),
  const Text('Tyres'),Wrap(spacing:8,children:['Stock','Semi-Slick','Slick'].map((x)=>ChoiceChip(label:Text(x),selected:tyres==x,onSelected:(_)=>setState(()=>tyres=x))).toList()),
  const SizedBox(height:18),const Label('AERO'),slider('Front Aero',front,(v)=>setState(()=>front=v),0,10),slider('Rear Aero',rear,(v)=>setState(()=>rear=v),0,10),
  const Label('SUSPENSION'),slider('Ride Height',ride,(v)=>setState(()=>ride=v),-20,20),slider('Stiffness',stiff,(v)=>setState(()=>stiff=v),0,10),
  const SizedBox(height:20),FilledButton.icon(style:FilledButton.styleFrom(backgroundColor:const Color(0xff7113bd),padding:const EdgeInsets.all(16)),onPressed:(){widget.onSave({'game':widget.game,'vehicle':widget.vehicle,'title':name.text,'type':type});Navigator.popUntil(c,(r)=>r.isFirst);},icon:const Icon(Icons.check),label:const Text('Save Setup'))
 ]));
 Widget field(TextEditingController c,String l,[int lines=1])=>Padding(padding:const EdgeInsets.symmetric(vertical:6),child:TextField(controller:c,maxLines:lines,decoration:InputDecoration(labelText:l,filled:true,fillColor:card,border:OutlineInputBorder(borderRadius:BorderRadius.circular(8)))));
 Widget slider(String l,double v,ValueChanged<double> f,double min,double max)=>Row(children:[SizedBox(width:90,child:Text(l,style:const TextStyle(fontSize:12))),Expanded(child:Slider(value:v,min:min,max:max,onChanged:f)),SizedBox(width:32,child:Text(v.round().toString()))]);
}
class MySetups extends StatelessWidget {
  final List items;
  final ValueChanged<dynamic> onDelete;

  const MySetups({
    super.key,
    required this.items,
    required this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        const Text(
          'My Setups',
          style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
        ),
        const SizedBox(height: 12),
        if (items.isEmpty)
          const Text(
            'No saved setups yet.',
            style: TextStyle(color: Colors.white60),
          )
        else
          ...items.map(
            (setup) => Card(
              color: card,
              child: ListTile(
                leading: const Icon(Icons.tune, color: purple),
                title: Text(setup['title'] ?? 'Setup'),
                subtitle: Text(
                  '${setup['game'] ?? ''}\n${setup['vehicle'] ?? ''}',
                ),
                isThreeLine: true,
                trailing: IconButton(
                  icon: const Icon(Icons.delete_outline),
                  onPressed: () => onDelete(setup),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
class Hardware extends StatefulWidget{const Hardware({super.key});@override State<Hardware> createState()=>_Hardware();}
class _Hardware extends State<Hardware>{
 List<dynamic> makers=[],profiles=[]; String q='';
 @override void initState(){super.initState();load();}
 Future<void> load()async{
  final raw=jsonDecode(await rootBundle.loadString('assets/catalog/hardware.json'));
  final p=await SharedPreferences.getInstance();
  makers=raw['manufacturers']; profiles=jsonDecode(p.getString('hw_profiles')??'[]');
  if(mounted)setState((){});
 }
 Future<void> saveProfile(dynamic maker,dynamic dev)async{
  final rotation=TextEditingController(text:dev['name'].toString().contains('RS50')?'720':'');
  final ffb=TextEditingController(); final damping=TextEditingController(); final notes=TextEditingController();
  await showDialog<void>(context:context,builder:(dc)=>AlertDialog(
   title:Text(dev['name']),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
    Text('${maker['name']} • ${dev['drive']}${dev['torque_nm']!=null?' • ${dev['torque_nm']} Nm':''}',style:const TextStyle(color:gold)),
    const SizedBox(height:8),TextField(controller:rotation,decoration:const InputDecoration(labelText:'Rotation / steering angle')),
    TextField(controller:ffb,decoration:const InputDecoration(labelText:'Overall force feedback')),
    TextField(controller:damping,decoration:const InputDecoration(labelText:'Damping')),
    TextField(controller:notes,maxLines:3,decoration:const InputDecoration(labelText:'Notes'))
   ])),actions:[FilledButton(onPressed:(){
    profiles.add({'maker':maker['name'],'device':dev['name'],'rotation':rotation.text,'ffb':ffb.text,'damping':damping.text,'notes':notes.text});
    Navigator.pop(dc);},child:const Text('Save Profile'))]));
  final p=await SharedPreferences.getInstance(); await p.setString('hw_profiles',jsonEncode(profiles)); if(mounted)setState((){});
 }
 @override Widget build(BuildContext c){
  final filtered=<Map<String,dynamic>>[];
  for(final m in makers){for(final d in m['devices']){if(('${m['name']} ${d['name']}').toLowerCase().contains(q.toLowerCase()))filtered.add({'m':m,'d':d});}}
  return ListView(padding:const EdgeInsets.all(18),children:[
   const Text('Hardware',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900)),
   const Text('Choose your exact wheel or wheelbase, then save game-specific settings.',style:TextStyle(color:gold,fontSize:12)),
   const SizedBox(height:14),
   TextField(onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:'Search G29, RS50, R12, T300...',filled:true,fillColor:card,border:OutlineInputBorder(borderRadius:BorderRadius.circular(10),borderSide:BorderSide.none))),
   if(profiles.isNotEmpty)...[const SizedBox(height:18),const Label('MY HARDWARE PROFILES'),const SizedBox(height:8),
    ...profiles.map((x)=>Card(color:card,child:ListTile(leading:const Icon(Icons.sports_esports,color:purple),title:Text('${x['maker']} ${x['device']}'),subtitle:Text('Rotation: ${x['rotation'].toString().isEmpty?'—':x['rotation']}  •  FFB: ${x['ffb'].toString().isEmpty?'—':x['ffb']}'))))],
   const SizedBox(height:18),const Label('HARDWARE CATALOGUE'),const SizedBox(height:8),
   ...filtered.map((x){final m=x['m'],d=x['d'];return Card(color:card,child:ListTile(
    onTap:()=>saveProfile(m,d),leading:const Icon(Icons.settings_input_component_rounded,color:gold),
    title:Text('${m['name']} ${d['name']}',style:const TextStyle(fontWeight:FontWeight.w800)),
    subtitle:Text('${d['drive']}${d['torque_nm']!=null?' • ${d['torque_nm']} Nm':''}\n${(d['platforms'] as List).join(' • ')}',maxLines:2),
    trailing:const Icon(Icons.add_circle_outline,color:purple)));})
  ]);
 }
}
