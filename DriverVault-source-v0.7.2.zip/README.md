# DriverVault v0.7 catalogue/hardware build

This is the hold-before-upload build requested after v0.6.

Hardware is now a real searchable catalogue rather than a generic text box:
Logitech G (G25/G27/G29/G920/G923/PRO/RS50), Fanatec CSL/GT DD/ClubSport/Podium,
MOZA R3 through R25 Ultra, Thrustmaster, PXN, Turtle Beach and HORI.
Selecting exact hardware creates a persistent profile for rotation, FFB, damping and notes.
RS50 starts at 720 degrees as a convenience but remains editable.

Game catalogue remains separated from user data. Current verified data imports are retained,
with the architecture ready for remote catalogue replacement without overwriting personal setups.
