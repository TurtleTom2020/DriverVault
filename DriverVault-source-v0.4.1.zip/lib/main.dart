import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main()=>runApp(const DriverVault());
const bg=Color(0xff08070c), surface=Color(0xff15111d), purple=Color(0xff9d4dff), gold=Color(0xffffc52f);

class DriverVault extends StatelessWidget{
 const DriverVault({super.key});
 @override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'DriverVault',
 theme:ThemeData.dark(useMaterial3:true).copyWith(scaffoldBackgroundColor:bg,colorScheme:ColorScheme.fromSeed(seedColor:purple,brightness:Brightness.dark)),
 home:const Shell());
}
class Shell extends StatefulWidget{const Shell({super.key});@override State<Shell> createState()=>_Shell();}
class _Shell extends State<Shell>{
 int tab=0; List games=[]; List saved=[]; String scheme='Purple + Gold',finish='Metallic';
 Color get accent=>switch(scheme){'Electric Blue'=>const Color(0xff3388ff),'Crimson'=>const Color(0xffff4058),'Emerald'=>const Color(0xff36df75),'Copper'=>const Color(0xffff8c32),_=>purple};
 Color get accent2=>scheme=='Purple + Gold'?gold:accent.withValues(alpha:.75);
 @override void initState(){super.initState();load();}
 Future<void> load()async{games=jsonDecode(await rootBundle.loadString('assets/catalog/catalog.json'))['games'];final p=await SharedPreferences.getInstance();saved=jsonDecode(p.getString('dv_saved')??'[]');scheme=p.getString('dv_scheme')??scheme;finish=p.getString('dv_finish')??finish;if(mounted)setState((){});}
 Future<void> save()async{final p=await SharedPreferences.getInstance();await p.setString('dv_saved',jsonEncode(saved));}
 @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:IndexedStack(index:tab,children:[home(),Catalogue(games:games,accent:accent,accent2:accent2,onSave:(x){saved.add(x);save();setState((){});}),setups(),const Hardware()])),
 bottomNavigationBar:NavigationBar(height:76,backgroundColor:const Color(0xff100d15),indicatorColor:accent.withValues(alpha:.22),selectedIndex:tab,onDestinationSelected:(v)=>setState(()=>tab=v),destinations:const[
 NavigationDestination(icon:Icon(Icons.home_rounded),label:'Home'),NavigationDestination(icon:Icon(Icons.grid_view_rounded),label:'Catalogue'),NavigationDestination(icon:Icon(Icons.tune_rounded),label:'My Setups'),NavigationDestination(icon:Icon(Icons.sports_esports_rounded),label:'Hardware')]));
 Widget home()=>ListView(padding:const EdgeInsets.fromLTRB(18,14,18,28),children:[
   Row(children:[Image.asset('assets/branding/drivervault_icon.png',width:78,height:78),const SizedBox(width:13),const Expanded(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
    Text('DRIVER',style:TextStyle(fontSize:15,fontWeight:FontWeight.w900,letterSpacing:4,color:Colors.white70)),
    Text('VAULT',style:TextStyle(fontSize:34,height:.95,fontWeight:FontWeight.w900,letterSpacing:1.5,color:gold)),
    SizedBox(height:6),Text('YOUR GAMES • YOUR SETUPS • ONE VAULT',style:TextStyle(fontSize:9,letterSpacing:.8,color:Colors.white54))])),
    IconButton.filledTonal(onPressed:appearance,icon:const Icon(Icons.palette_rounded))]),
   const SizedBox(height:24),sectionTitle('YOUR GARAGE'),const SizedBox(height:11),
   SizedBox(height:190,child:ListView(scrollDirection:Axis.horizontal,children:games.map((g)=>hero(g)).toList())),
   const SizedBox(height:25),Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[const Text('Quick Access',style:TextStyle(fontSize:22,fontWeight:FontWeight.w800)),TextButton(onPressed:()=>setState(()=>tab=1),child:const Text('VIEW ALL'))]),
   Row(children:[Expanded(child:quick(Icons.search_rounded,'Catalogue','Find vehicles',()=>setState(()=>tab=1))),const SizedBox(width:11),Expanded(child:quick(Icons.tune_rounded,'My Setups','${saved.length} saved',()=>setState(()=>tab=2)))]),
   const SizedBox(height:27),sectionTitle('RECENT ACTIVITY'),const SizedBox(height:11),
   if(saved.isEmpty) card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(Icons.garage_outlined,size:34,color:accent),const SizedBox(height:10),const Text('Your vault is empty',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:5),const Text('Search the catalogue and save your first vehicle setup.',style:TextStyle(color:Colors.white60))]))
   else ...saved.reversed.take(3).map((s)=>Card(color:surface,child:ListTile(leading:Container(width:48,height:48,decoration:BoxDecoration(borderRadius:BorderRadius.circular(12),gradient:LinearGradient(colors:[accent,accent2])),child:const Icon(Icons.tune,color:Colors.black)),title:Text(s['title'],style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${s['game']} • ${s['vehicle']}'))))
 ]);
 Widget hero(dynamic g)=>GestureDetector(onTap:()=>setState(()=>tab=1),child:Container(width:310,margin:const EdgeInsets.only(right:13),decoration:BoxDecoration(borderRadius:BorderRadius.circular(23),border:Border.all(color:accent2.withValues(alpha:.5)),boxShadow:[BoxShadow(color:accent.withValues(alpha:.16),blurRadius:22)]),child:ClipRRect(borderRadius:BorderRadius.circular(22),child:Stack(fit:StackFit.expand,children:[Image.asset(g['art'],fit:BoxFit.cover),const DecoratedBox(decoration:BoxDecoration(gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Colors.transparent,Color(0xdd050408)]))),Positioned(left:18,right:16,bottom:16,child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(g['name'],style:const TextStyle(fontSize:21,fontWeight:FontWeight.w900)),const SizedBox(height:3),Text('${(g['vehicles'] as List).length} starter vehicles • Tap to open',style:const TextStyle(color:Colors.white70,fontSize:12))]))]))));
 Widget quick(IconData i,String a,String b,VoidCallback f)=>InkWell(onTap:f,borderRadius:BorderRadius.circular(18),child:card(Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Container(padding:const EdgeInsets.all(10),decoration:BoxDecoration(shape:BoxShape.circle,color:accent.withValues(alpha:.16)),child:Icon(i,color:accent)),const SizedBox(height:14),Text(a,style:const TextStyle(fontWeight:FontWeight.bold,fontSize:16)),Text(b,style:const TextStyle(color:Colors.white54,fontSize:12))])));
 Widget card(Widget x)=>Container(padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:surface,borderRadius:BorderRadius.circular(20),border:Border.all(color:Colors.white.withValues(alpha:.04))),child:x);
 Widget sectionTitle(String x)=>Text(x,style:TextStyle(color:accent,fontSize:13,fontWeight:FontWeight.w900,letterSpacing:2));
 Widget setups()=>ListView(padding:const EdgeInsets.all(18),children:[const Text('MY SETUPS',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900)),Text('Every tune, controller profile and build in one place.',style:TextStyle(color:accent2)),const SizedBox(height:18),if(saved.isEmpty)const Text('No saved setups yet.',style:TextStyle(color:Colors.white60))else ...saved.map((s)=>Card(color:surface,child:ListTile(leading:Icon(Icons.bookmark_rounded,color:accent2),title:Text(s['title'],style:const TextStyle(fontWeight:FontWeight.bold)),subtitle:Text('${s['game']}\n${s['vehicle']}'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:(){saved.remove(s);save();setState((){});}))))]);
 void appearance()=>showModalBottomSheet(context:context,isScrollControlled:true,backgroundColor:surface,builder:(c)=>Padding(padding:const EdgeInsets.all(22),child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[
 const Text('VAULT APPEARANCE',style:TextStyle(fontSize:22,fontWeight:FontWeight.w900)),const SizedBox(height:6),const Text('Choose the colour identity and surface finish.',style:TextStyle(color:Colors.white60)),const SizedBox(height:18),
 const Text('COLOUR SCHEME',style:TextStyle(fontSize:11,fontWeight:FontWeight.bold,letterSpacing:1.5)),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:['Purple + Gold','Electric Blue','Crimson','Emerald','Copper'].map((e)=>ChoiceChip(label:Text(e),selected:scheme==e,onSelected:(_)async{scheme=e;final p=await SharedPreferences.getInstance();await p.setString('dv_scheme',e);setState((){});})).toList()),
 const SizedBox(height:18),const Text('FINISH',style:TextStyle(fontSize:11,fontWeight:FontWeight.bold,letterSpacing:1.5)),const SizedBox(height:8),Wrap(spacing:8,runSpacing:8,children:['Solid','Matte','Metallic','Pearlescent','Two-tone'].map((e)=>ChoiceChip(label:Text(e),selected:finish==e,onSelected:(_)async{finish=e;final p=await SharedPreferences.getInstance();await p.setString('dv_finish',e);setState((){});})).toList()),const SizedBox(height:12)])));
}

class Catalogue extends StatefulWidget{final List games;final Color accent,accent2;final ValueChanged<Map<String,dynamic>> onSave;const Catalogue({super.key,required this.games,required this.accent,required this.accent2,required this.onSave});@override State<Catalogue> createState()=>_Cat();}
class _Cat extends State<Catalogue>{String gid='fh5',q='';@override Widget build(BuildContext c){if(widget.games.isEmpty)return const Center(child:CircularProgressIndicator());final g=widget.games.firstWhere((x)=>x['id']==gid,orElse:()=>widget.games.first);final cars=(g['vehicles'] as List).where((v)=>('${v['year']} ${v['name']}').toLowerCase().contains(q.toLowerCase())).toList();return CustomScrollView(slivers:[
 SliverToBoxAdapter(child:Stack(children:[Image.asset(g['art'],height:215,width:double.infinity,fit:BoxFit.cover),Container(height:215,decoration:const BoxDecoration(gradient:LinearGradient(begin:Alignment.topCenter,end:Alignment.bottomCenter,colors:[Colors.transparent,bg])),padding:const EdgeInsets.fromLTRB(18,0,18,18),alignment:Alignment.bottomLeft,child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[const Text('CATALOGUE',style:TextStyle(fontSize:12,fontWeight:FontWeight.bold,letterSpacing:2)),Text(g['name'],style:const TextStyle(fontSize:27,fontWeight:FontWeight.w900))]))])),
 SliverToBoxAdapter(child:Padding(padding:const EdgeInsets.fromLTRB(18,0,18,12),child:Column(children:[SizedBox(height:43,child:ListView(scrollDirection:Axis.horizontal,children:widget.games.map((x)=>Padding(padding:const EdgeInsets.only(right:7),child:ChoiceChip(label:Text(x['name']),selected:gid==x['id'],onSelected:(_)=>setState(()=>gid=x['id'])))).toList())),const SizedBox(height:12),TextField(onChanged:(v)=>setState(()=>q=v),decoration:InputDecoration(prefixIcon:const Icon(Icons.search),hintText:'Search make, model or vehicle…',filled:true,fillColor:surface,border:OutlineInputBorder(borderRadius:BorderRadius.circular(17),borderSide:BorderSide.none)))]))),
 if(cars.isEmpty)const SliverToBoxAdapter(child:Padding(padding:EdgeInsets.all(24),child:Text('This game catalogue is ready for expansion; no starter vehicles are loaded yet.',style:TextStyle(color:Colors.white60))))
 else
   SliverList(
     delegate: SliverChildBuilderDelegate(
       (context, i) {
         final v = cars[i];
         return Container(
           margin: const EdgeInsets.fromLTRB(18, 5, 18, 5),
           decoration: BoxDecoration(color: surface, borderRadius: BorderRadius.circular(17)),
           child: ListTile(
             contentPadding: const EdgeInsets.all(13),
             leading: Container(
               width: 62, height: 62,
               decoration: BoxDecoration(
                 borderRadius: BorderRadius.circular(13),
                 gradient: LinearGradient(colors: [
                   widget.accent.withValues(alpha: .7),
                   widget.accent2.withValues(alpha: .45),
                 ]),
               ),
               child: const Icon(Icons.directions_car_filled_rounded, size: 31),
             ),
             title: Text(
               '${v['year']} ${v['name']}'.trim(),
               style: const TextStyle(fontWeight: FontWeight.w800),
             ),
             subtitle: Padding(
               padding: const EdgeInsets.only(top: 5),
               child: Wrap(spacing: 6, children: [chip(v['drive']), chip(v['type'])]),
             ),
             trailing: const Icon(Icons.chevron_right),
             onTap: () => edit(context, g['name'], v['name']),
           ),
         );
       },
       childCount: cars.length,
     ),
   )
 ]);}
 Widget chip(String s)=>Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:3),decoration:BoxDecoration(color:Colors.white.withValues(alpha:.07),borderRadius:BorderRadius.circular(6)),child:Text(s,style:const TextStyle(fontSize:10,color:Colors.white70)));
 void edit(BuildContext c,String game,String vehicle){final title=TextEditingController(text:'General Setup'),notes=TextEditingController(),tyres=TextEditingController(),gearing=TextEditingController();showModalBottomSheet(context:c,isScrollControlled:true,backgroundColor:surface,builder:(c)=>Padding(padding:EdgeInsets.fromLTRB(20,22,20,MediaQuery.of(c).viewInsets.bottom+22),child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.start,children:[Text(vehicle,style:const TextStyle(fontSize:25,fontWeight:FontWeight.w900)),Text(game,style:TextStyle(color:widget.accent2)),const SizedBox(height:15),TextField(controller:title,decoration:const InputDecoration(labelText:'Setup name')),TextField(controller:tyres,decoration:const InputDecoration(labelText:'Tyres / pressures')),TextField(controller:gearing,decoration:const InputDecoration(labelText:'Gearing / transmission')),TextField(controller:notes,maxLines:3,decoration:const InputDecoration(labelText:'Notes')),const SizedBox(height:18),SizedBox(width:double.infinity,child:FilledButton.icon(onPressed:(){widget.onSave({'game':game,'vehicle':vehicle,'title':title.text,'notes':notes.text,'tyres':tyres.text,'gearing':gearing.text});Navigator.pop(c);},icon:const Icon(Icons.lock_rounded),label:const Text('SAVE TO VAULT')))]))));}
}
class Hardware extends StatefulWidget {
  const Hardware({super.key});

  @override
  State<Hardware> createState() => _HW();
}

class _HW extends State<Hardware> {
  List<dynamic> items = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    items = jsonDecode(prefs.getString('dv_hw') ?? '[]');
    if (mounted) setState(() {});
  }

  Future<void> add() async {
    final name = TextEditingController();
    final notes = TextEditingController();

    await showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Add hardware'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: name,
              decoration: const InputDecoration(labelText: 'Hardware name'),
            ),
            TextField(
              controller: notes,
              decoration:
                  const InputDecoration(labelText: 'Base/controller settings'),
            ),
          ],
        ),
        actions: [
          FilledButton(
            onPressed: () {
              items.add({'name': name.text, 'notes': notes.text});
              Navigator.pop(dialogContext);
            },
            child: const Text('Save'),
          ),
        ],
      ),
    );

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('dv_hw', jsonEncode(items));
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton(
        onPressed: add,
        child: const Icon(Icons.add),
      ),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          const Text(
            'HARDWARE',
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.w900),
          ),
          const Text(
            'Wheel bases • wheels • pedals • controllers',
            style: TextStyle(color: gold),
          ),
          const SizedBox(height: 18),
          if (items.isEmpty)
            const Text(
              'No hardware profiles yet.',
              style: TextStyle(color: Colors.white60),
            )
          else
            ...items.map(
              (h) => Card(
                color: surface,
                child: ListTile(
                  leading: const Icon(
                    Icons.sports_esports_rounded,
                    color: gold,
                  ),
                  title: Text(h['name'] ?? ''),
                  subtitle: Text(h['notes'] ?? ''),
                ),
              ),
            ),
        ],
      ),
    );
  }
}
