# DriverVault v0.4
This is the first UI rebuild that treats the approved Image-2 concept as the screen specification rather than a colour reference.

Changes:
- Large DriverVault DV shield and DRIVER / VAULT wordmark header.
- Cinematic image-led game cards with full game names.
- Catalogue hero artwork, game selector, richer vehicle cards and setup editor.
- Purple + Gold default identity.
- Selectable colour schemes and Solid / Matte / Metallic / Pearlescent / Two-tone finish controls.
- Custom DriverVault game-card artwork included locally so the prototype does not redistribute publisher artwork without permission.
- Launcher icon generation configured so Android no longer falls back to the Flutter icon.
- Saved setups and hardware remain separate from catalogue data.

The starter vehicle catalogue is still intentionally incomplete. Full remote catalogue work is a separate data milestone and must not overwrite personal setups.
