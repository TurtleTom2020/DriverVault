#!/usr/bin/env python3
"""DriverVault v2.0 game-image mapper.
Searches game-specific MediaWiki/Fandom repositories for vehicle artwork, validates
that each URL returns real image bytes, and writes only verified mappings.
Existing FH5 mappings are preserved.
"""
import json,re,time,unicodedata,urllib.parse,urllib.request
from concurrent.futures import ThreadPoolExecutor,as_completed
from pathlib import Path

CAT=Path('assets/catalog/catalog.json')
data=json.loads(CAT.read_text(encoding='utf-8'))
UA='DriverVault/2.0 (+https://github.com/TurtleTom2020/DriverVault)'

SOURCES={
 'carx':['https://carx.fandom.com/api.php'],
 'beamng':['https://beamng.fandom.com/api.php'],
 'ets2':['https://truck-simulator.fandom.com/api.php'],
 'ats':['https://truck-simulator.fandom.com/api.php'],
 'assetto':['https://assettocorsa.fandom.com/api.php'],
 'wrc':['https://easportswrc.fandom.com/api.php','https://wrc.fandom.com/api.php'],
 'alaskan':['https://alaskanroadtruckers.wiki.gg/api.php','https://alaskan-road-truckers.fandom.com/api.php'],
 'mudrunner':['https://spintires.fandom.com/api.php'],
 'snowrunner':['https://spintires.fandom.com/api.php'],
 'gt7':['https://gran-turismo.fandom.com/api.php'],
}
GAME_TERMS={'carx':'CarX','beamng':'BeamNG','ets2':'Euro Truck Simulator 2','ats':'American Truck Simulator','assetto':'Assetto Corsa','wrc':'EA SPORTS WRC','alaskan':'Alaskan Road Truckers','mudrunner':'MudRunner','snowrunner':'SnowRunner','gt7':'Gran Turismo 7'}

def norm(s):
 s=unicodedata.normalize('NFKD',str(s)).encode('ascii','ignore').decode().lower()
 return re.sub(r'[^a-z0-9]+',' ',s).strip()

def request_json(url,attempts=4):
 last=None
 for n in range(attempts):
  try:
   req=urllib.request.Request(url,headers={'User-Agent':UA,'Accept':'application/json'})
   with urllib.request.urlopen(req,timeout=25) as r:return json.loads(r.read().decode('utf-8','replace'))
  except Exception as e:last=e;time.sleep(1.5*(n+1))
 raise last

def image_ok(url):
 try:
  req=urllib.request.Request(url,headers={'User-Agent':UA,'Range':'bytes=0-2047'})
  with urllib.request.urlopen(req,timeout=20) as r:
   c=(r.headers.get('Content-Type') or '').lower(); b=r.read(2048)
   return c.startswith('image/') and len(b)>64 and (b.startswith(b'\x89PNG') or b.startswith(b'\xff\xd8') or b[:4] in (b'RIFF',b'GIF8') or b.startswith(b'\x00\x00\x00'))
 except Exception:return False

def vehicle_label(v): return ' '.join(x for x in [str(v.get('make','')).strip(),str(v.get('model','')).strip(),str(v.get('year','')).strip()] if x).strip()

def score(title,label,gid):
 t=norm(title); q=norm(label); qt=set(q.split()); tt=set(t.split())
 if not qt:return -999
 bad=('logo','icon','badge','map','track','livery editor','screenshot ui','manufacturer','flag','helmet','wheel')
 if any(x in t for x in bad):return -500
 sc=40*len(qt&tt)-22*len(qt-tt)-5*len(tt-qt)
 if q in t:sc+=220
 model=norm(label.rsplit(' ',1)[0]);
 if model and model in t:sc+=80
 if norm(GAME_TERMS[gid]) in t:sc+=30
 return sc

def candidates(api,label,gid):
 # Search file namespace directly. A second shorter query helps names containing years/quotes.
 queries=[label, re.sub(r"[‘’']?\d{2,4}$",'',label).strip()]
 out=[]; seen=set()
 for q in queries:
  params={'action':'query','generator':'search','gsrsearch':q,'gsrnamespace':'6','gsrlimit':'12','prop':'imageinfo','iiprop':'url|mime|size','iiurlwidth':'1000','format':'json','formatversion':'2'}
  root=request_json(api+'?'+urllib.parse.urlencode(params))
  for p in root.get('query',{}).get('pages',[]):
   ii=(p.get('imageinfo') or [{}])[0]; u=ii.get('thumburl') or ii.get('url') or ''
   if not u.startswith('https://') or not str(ii.get('mime','')).startswith('image/'):continue
   if u in seen:continue
   seen.add(u);out.append((score(p.get('title',''),label,gid),p.get('title',''),u,ii.get('width',0),ii.get('height',0)))
 return sorted(out,reverse=True)

def page_candidates(api,label,gid):
 # Many game wikis keep the useful vehicle image on the article page rather than
 # in a filename containing the vehicle name. Search articles, then request their
 # lead/page image. This fixes sources where namespace-6 file search returns zero.
 out=[]; seen=set()
 queries=[label, re.sub(r"[‘’']?\d{2,4}$",'',label).strip()]
 for q in queries:
  try:
   params={'action':'query','generator':'search','gsrsearch':q,'gsrnamespace':'0','gsrlimit':'8',
           'prop':'pageimages','piprop':'thumbnail|original|name','pithumbsize':'1200',
           'format':'json','formatversion':'2'}
   root=request_json(api+'?'+urllib.parse.urlencode(params),attempts=2)
   for page in root.get('query',{}).get('pages',[]):
    u=((page.get('thumbnail') or {}).get('source') or (page.get('original') or {}).get('source') or '')
    if not u.startswith('https://') or u in seen: continue
    seen.add(u)
    sc=score(page.get('title',''),label,gid)+90
    out.append((sc,page.get('title',''),u,0,0))
  except Exception: pass
 return sorted(out,reverse=True)

def direct_pageimage(api,label,gid):
 # Exact-title pass catches short MudRunner/SnowRunner names such as C-255.
 try:
  params={'action':'query','titles':label,'prop':'pageimages','piprop':'thumbnail|original|name',
          'pithumbsize':'1200','format':'json','formatversion':'2'}
  root=request_json(api+'?'+urllib.parse.urlencode(params),attempts=2)
  for page in root.get('query',{}).get('pages',[]):
   u=((page.get('thumbnail') or {}).get('source') or (page.get('original') or {}).get('source') or '')
   if u.startswith('https://') and image_ok(u): return u,api,page.get('title',''),999
 except Exception: pass
 return None

def map_one(gid,v):
 label=vehicle_label(v)
 for api in SOURCES[gid]:
  exact=direct_pageimage(api,label,gid)
  if exact:return exact
  try:
   # Article images first, then filename search. Article images are substantially
   # more reliable on Spintires, Assetto and wiki.gg.
   cs=page_candidates(api,label,gid)+candidates(api,label,gid)
   cs=sorted(cs,reverse=True)
   for sc,title,u,w,h in cs[:8]:
    if sc<55:continue
    if w and h and max(w,h)<300:continue
    if image_ok(u):return u,api,title,sc
  except Exception:continue
 return None

def ensure_ids(g):
 used=set()
 for i,v in enumerate(g.get('vehicles',[])):
  if v.get('id'):used.add(v['id']);continue
  slug=norm(vehicle_label(v)).replace(' ','-') or str(i+1); base=f"{g['id']}:{slug}"; x=base;n=2
  while x in used:x=f'{base}-{n}';n+=1
  v['id']=x;used.add(x)

for g in data['games']:ensure_ids(g)

for g in data['games']:
 gid=g['id']
 if gid not in SOURCES:continue
 vehicles=g.get('vehicles',[])
 todo=[v for v in vehicles if not str(v.get('image','')).strip()]
 print(f'[{gid}] searching {len(todo)} unmapped vehicles...')
 mapped=0
 with ThreadPoolExecutor(max_workers=10) as ex:
  fut={ex.submit(map_one,gid,v):v for v in todo}
  for n,f in enumerate(as_completed(fut),1):
   v=fut[f]
   try:r=f.result()
   except Exception:r=None
   if r:
    u,api,title,sc=r;v['image']=u;v['imageSource']=api;v['imageMatch']=title;mapped+=1
   if n%25==0:print(f'  {n}/{len(todo)} checked, {mapped} new mappings')
 coverage=sum(bool(str(v.get('image','')).strip()) for v in vehicles)
 g['imageCoverage']=coverage;g['imageVerifiedAt']='2026-09-27'
 print(f'[{gid}] VERIFIED IMAGE COVERAGE {coverage}/{len(vehicles)}')
 # Checkpoint after every game so a long run never loses completed mappings.
 CAT.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
 print(f'[{gid}] checkpoint saved')

# Never permit the old v1.8 failure (all-zero non-FH5 catalogues) to ship.
fail=[]
for g in data['games']:
 if g['id'] in SOURCES:
  n=len(g.get('vehicles',[])); imgs=sum(bool(str(v.get('image','')).strip()) for v in g.get('vehicles',[]))
  if n and imgs==0:fail.append(g['id'])
fh=next(g for g in data['games'] if g['id']=='fh5')
if sum(bool(v.get('image')) for v in fh['vehicles'])<805:raise SystemExit('FH5 regression: image coverage below 805')
if fail:raise SystemExit('ZERO-IMAGE GATE FAILED: '+', '.join(fail))
data['version']='2.0.0'
CAT.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print('Image mapping complete; zero-image gate passed for every supported game source.')
