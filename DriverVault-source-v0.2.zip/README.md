# DriverVault

**Every game. Every setup. Saved.**

DriverVault is a cross-platform Flutter app for keeping driving-game settings, vehicle tunes and hardware profiles in one place.

## v0.2 foundation
- Game selector
- Built-in starter catalogue for Forza Horizon 5 and CarX Drift Racing Online
- Searchable vehicle list
- Create, edit, favourite and delete multiple setups per vehicle
- Game-specific setting fields
- Hardware profiles
- Local persistence with SharedPreferences
- Catalogue and personal data are kept separate
- Custom game and custom vehicle support

## Run
1. Install Flutter.
2. From this folder run `flutter create . --platforms=android,ios`.
3. Run `flutter pub get`.
4. Run `flutter run`.

The `flutter create .` step generates the standard Android/iOS runner folders while preserving the DriverVault source files.

### v0.2
- Fixed first GitHub Actions analyzer failure caused by Flutter's generated `MyApp` widget test.
- Cleaned initial analyzer lint notices.
