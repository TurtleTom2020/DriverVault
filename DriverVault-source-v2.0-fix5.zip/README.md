# DriverVault v0.7 catalogue/hardware build

This is the hold-before-upload build requested after v0.6.

Hardware is now a real searchable catalogue rather than a generic text box:
Logitech G (G25/G27/G29/G920/G923/PRO/RS50), Fanatec CSL/GT DD/ClubSport/Podium,
MOZA R3 through R25 Ultra, Thrustmaster, PXN, Turtle Beach and HORI.
Selecting exact hardware creates a persistent profile for rotation, FFB, damping and notes.
RS50 starts at 720 degrees as a convenience but remains editable.

Game catalogue remains separated from user data. Current verified data imports are retained,
with the architecture ready for remote catalogue replacement without overwriting personal setups.

## v2.0 fix3
Assetto Corsa image discovery moved away from United Corsa/Fandom to Assetto-DB manufacturer indexes + exact car pages. The mapper validates returned image bytes before accepting a mapping.

Fix3: Assetto Corsa image resolver moved to IGCD game-specific catalogue; failed runs now retain enriched source checkpoints.

## v2.0 Fix 4
- Uses the preserved #43 mapping checkpoint as the source baseline (successful mappings are baked in).
- Assetto Corsa resolver changed to IGCD's Assetto Corsa playable-vehicle catalogue, while DriverVault's existing 178 records remain the whitelist.
- Alaskan Road Truckers E/P variants fall back to the corresponding official wiki base-truck image, matching the game's six base truck families plus variants.
