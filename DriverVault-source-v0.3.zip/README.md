# DriverVault v0.3
Major visual rebuild based on the approved Image 2 direction.

Included: purple/gold DV shield branding, dashboard-style Home, game carousel, Catalogue/My Setups/Hardware navigation, searchable starter catalogue, persistent local setups and hardware, and selectable Purple+Gold/Blue/Red/Green/Copper themes.

The catalogue included here is deliberately starter data, not a claimed complete FH5 database. The architecture keeps catalogue data separate from personal saved setups so future catalogue updates cannot overwrite user data. Finish modes (solid, matte, metallic, pearlescent, two-tone) are represented in the theme foundation and will be expanded into the full renderer next.
